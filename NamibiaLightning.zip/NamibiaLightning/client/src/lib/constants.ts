// App information
export const APP_NAME = "Easy Pocket";
export const APP_VERSION = "1.0.0";

// Bitcoin constants
export const SATS_PER_BTC = 100000000;

// Machankura constants
export const MACHANKURA_URL = "https://web.8333.mobi/";
export const MACHANKURA_SMS_CODE = "8333";

// Merchant categories
export const MERCHANT_CATEGORIES = [
  "All",
  "Restaurants",
  "Retail",
  "Services",
  "Tourism",
  "Technology",
];

// Educational content categories
export const EDUCATIONAL_CATEGORIES = [
  "basics",
  "security",
  "economy",
  "technology",
];

// Transaction types
export const TRANSACTION_TYPES = {
  SEND: "send",
  RECEIVE: "receive",
  OFFLINE: "offline",
};

// Transaction status
export const TRANSACTION_STATUS = {
  PENDING: "pending",
  COMPLETED: "completed",
  FAILED: "failed",
};

// App navigation routes
export const ROUTES = {
  HOME: "/",
  MERCHANTS: "/merchants",
  SCAN: "/scan",
  SETTINGS: "/settings",
  LEARN: "/learn",
};
