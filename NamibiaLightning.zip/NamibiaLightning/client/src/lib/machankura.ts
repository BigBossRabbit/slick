import { MACHANKURA_URL, MACHANKURA_SMS_CODE } from "./constants";

// Machankura integration types
export type MachankuraMethod = "sms" | "ussd" | "voucher" | "lowdata";

interface MachankuraTransaction {
  id: string;
  amount: number;
  method: MachankuraMethod;
  phoneNumber?: string;
  code?: string;
  status: "created" | "pending" | "completed" | "failed";
  timestamp: Date;
}

// Simplified Machankura API client for MVP
export const machankura = {
  // Generate SMS payment instructions
  generateSmsInstructions: (amount: number, recipient?: string): string => {
    return `Send SMS with "PAY ${amount}" to ${MACHANKURA_SMS_CODE}${
      recipient ? ` for ${recipient}` : ""
    }`;
  },

  // Generate USSD code
  generateUssdCode: (amount: number): string => {
    // Format: *8333*amount#
    return `*${MACHANKURA_SMS_CODE}*${amount}#`;
  },

  // Generate voucher code
  generateVoucher: async (amount: number): Promise<string> => {
    // In real implementation, this would call the Machankura API
    // For MVP, we'll generate a mock voucher code
    const voucherPrefix = "EP";
    const randomChars = Math.random().toString(36).substring(2, 10).toUpperCase();
    return `${voucherPrefix}-${amount}-${randomChars}`;
  },

  // Validate voucher code
  validateVoucher: async (voucherCode: string): Promise<{ valid: boolean; amount?: number }> => {
    // In real implementation, this would verify with the Machankura API
    // For MVP, we'll just check format
    const parts = voucherCode.split("-");
    if (parts.length !== 3 || parts[0] !== "EP") {
      return { valid: false };
    }
    
    const amount = parseInt(parts[1]);
    if (isNaN(amount)) {
      return { valid: false };
    }
    
    return { valid: true, amount };
  },

  // Get Machankura web URL
  getWebUrl: (): string => {
    return MACHANKURA_URL;
  },
  
  // Get a deep link to activate low data mode
  getLowDataModeUrl: (): string => {
    return `${MACHANKURA_URL}?mode=lowdata`;
  }
};
