import { useWallet } from "./useWallet";
import { useLanguageContext } from "@/contexts/LanguageContext";
import { useState, useEffect } from "react";

export function useCurrencyConverter() {
  const { satoshiToFiat } = useWallet();
  const { currency } = useLanguageContext();
  const [inputAmount, setInputAmount] = useState<number | null>(null);
  const [inputType, setInputType] = useState<"sats" | "fiat">("sats");
  const [outputAmount, setOutputAmount] = useState<number | null>(null);

  // Update output value when input changes
  useEffect(() => {
    if (inputAmount === null) {
      setOutputAmount(null);
      return;
    }

    if (inputType === "sats") {
      // Convert sats to fiat
      setOutputAmount(satoshiToFiat(inputAmount));
    } else {
      // Convert fiat to sats
      // Avoid division by zero
      const rate = satoshiToFiat(1);
      if (rate === 0) {
        setOutputAmount(0);
      } else {
        setOutputAmount(inputAmount / rate);
      }
    }
  }, [inputAmount, inputType, satoshiToFiat]);

  // Format output value for display
  const formattedOutput = (): string => {
    if (outputAmount === null) return "";
    
    if (inputType === "sats") {
      // If input is sats, output is fiat
      return `${currency} ${outputAmount.toFixed(2)}`;
    } else {
      // If input is fiat, output is sats
      return `${Math.round(outputAmount).toLocaleString()} sats`;
    }
  };

  const toggleInputType = () => {
    // Swap input type and recalculate
    if (outputAmount !== null) {
      setInputAmount(outputAmount);
    }
    setInputType(inputType === "sats" ? "fiat" : "sats");
  };

  return {
    inputAmount,
    setInputAmount,
    inputType,
    setInputType,
    outputAmount,
    formattedOutput,
    toggleInputType,
  };
}
