import { useWalletContext } from "@/contexts/WalletContext";
import { useLanguageContext } from "@/contexts/LanguageContext";
import { useEffect, useMemo } from "react";

export function useWallet() {
  const {
    wallet,
    isWalletLoading,
    transactions,
    isTransactionsLoading,
    exchangeRate,
    isExchangeRateLoading,
    fetchWalletData,
    sendPayment,
    generateInvoice,
  } = useWalletContext();

  // Load wallet data when the hook is first used
  useEffect(() => {
    fetchWalletData();
  }, [fetchWalletData]);

  const { currency } = useLanguageContext();

  // Format balances
  const formattedBalances = useMemo(() => {
    if (!wallet) {
      return {
        formattedSatoshiBalance: "0",
        formattedBtcBalance: "0.00000000 BTC",
        formattedFiatBalance: `${currency} 0.00`,
      };
    }

    // Format satoshi
    const formattedSatoshiBalance = wallet.balance.toLocaleString();
    
    // Format BTC (1 BTC = 100,000,000 sats)
    const btcValue = wallet.balance / 100000000;
    const formattedBtcBalance = `${btcValue.toFixed(8)} BTC`;
    
    // Format fiat
    let fiatValue = 0;
    if (exchangeRate) {
      fiatValue = wallet.balance * exchangeRate.satoshiToNAD;
    }
    const formattedFiatBalance = `${currency} ${fiatValue.toFixed(2)}`;

    return {
      formattedSatoshiBalance,
      formattedBtcBalance,
      formattedFiatBalance,
    };
  }, [wallet, exchangeRate, currency]);

  // Convert satoshi to fiat
  const satoshiToFiat = (satoshi: number): number => {
    if (!exchangeRate) return 0;
    return satoshi * exchangeRate.satoshiToNAD;
  };

  // Format transactions for display
  const formattedTransactions = useMemo(() => {
    return transactions.map((transaction) => {
      const isReceived = transaction.amount > 0;
      const amountSats = Math.abs(transaction.amount);
      const amountFiat = satoshiToFiat(amountSats);
      const formattedAmount = `${isReceived ? '+' : '-'}${amountSats.toLocaleString()} sats`;
      const formattedFiatAmount = `${currency} ${amountFiat.toFixed(2)}`;
      const date = new Date(transaction.timestamp);
      const formattedDate = date.toLocaleDateString();
      const formattedTime = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      
      return {
        ...transaction,
        isReceived,
        amountSats,
        amountFiat,
        formattedAmount,
        formattedFiatAmount,
        formattedDate,
        formattedTime,
      };
    });
  }, [transactions, currency, satoshiToFiat]);

  return {
    wallet,
    isWalletLoading,
    transactions: formattedTransactions,
    isTransactionsLoading,
    exchangeRate,
    isExchangeRateLoading,
    fetchWalletData,
    sendPayment,
    generateInvoice,
    ...formattedBalances,
    satoshiToFiat,
  };
}
