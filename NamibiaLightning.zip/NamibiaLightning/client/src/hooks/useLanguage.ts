import { useTranslation } from "react-i18next";
import { useLanguageContext } from "@/contexts/LanguageContext";
import { useCallback } from "react";

export function useLanguage() {
  const { t } = useTranslation();
  const { 
    language, 
    setLanguage, 
    currency, 
    setCurrency, 
    dataSavingMode, 
    setDataSavingMode, 
    user 
  } = useLanguageContext();

  // Available languages
  const languages = [
    { code: "en", name: "English" },
    { code: "af", name: "Afrikaans" },
    { code: "ow", name: "Oshiwambo" },
  ];

  // Available currencies
  const currencies = [
    { code: "NAD", symbol: "N$", name: "Namibian Dollar" },
    { code: "USD", symbol: "$", name: "US Dollar" },
    { code: "EUR", symbol: "€", name: "Euro" },
    { code: "ZAR", symbol: "R", name: "South African Rand" },
  ];

  // Find current language object
  const currentLanguage = languages.find(lang => lang.code === language) || languages[0];
  
  // Find current currency object
  const currentCurrency = currencies.find(curr => curr.code === currency) || currencies[0];

  // Format a number as currency
  const formatCurrency = useCallback((amount: number): string => {
    const currencyObj = currencies.find(curr => curr.code === currency) || currencies[0];
    return `${currencyObj.symbol}${amount.toFixed(2)}`;
  }, [currency, currencies]);

  return {
    t,
    language,
    setLanguage,
    languages,
    currentLanguage,
    currency,
    setCurrency,
    currencies,
    currentCurrency,
    formatCurrency,
    dataSavingMode,
    setDataSavingMode,
    user,
  };
}
