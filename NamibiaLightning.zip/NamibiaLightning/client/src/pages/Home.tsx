import { useState } from "react";
import AppHeader from "@/components/AppHeader";
import WalletDashboard from "@/components/WalletDashboard";
import ActionShortcuts from "@/components/ActionShortcuts";
import EducationSection from "@/components/EducationSection";
import TransactionHistory from "@/components/TransactionHistory";
import BottomNavigation from "@/components/BottomNavigation";
import SideDrawer from "@/components/SideDrawer";
import ReceiveModal from "@/components/ReceiveModal";
import SendModal from "@/components/SendModal";
import ECashModal from "@/components/ECashModal";
import OfflineOptionsModal from "@/components/OfflineOptionsModal";
import { useLanguage } from "@/hooks/useLanguage";
import { ROUTES } from "@/lib/constants";
import { useQuery } from "@tanstack/react-query";

export default function Home() {
  const { t } = useLanguage();
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isReceiveModalOpen, setIsReceiveModalOpen] = useState(false);
  const [isSendModalOpen, setIsSendModalOpen] = useState(false);
  const [isOfflineModalOpen, setIsOfflineModalOpen] = useState(false);
  const [isECashModalOpen, setIsECashModalOpen] = useState(false);

  // Fetch educational content for the home page
  const { data: educationalContent } = useQuery({
    queryKey: ["/api/educational-content"],
  });

  // Handle wallet actions
  const handleSend = () => setIsSendModalOpen(true);
  const handleReceive = () => setIsReceiveModalOpen(true);
  const handleOfflineMode = () => setIsOfflineModalOpen(true);
  const handleECash = () => setIsECashModalOpen(true);

  // Handle drawer
  const openDrawer = () => setIsDrawerOpen(true);
  const closeDrawer = () => setIsDrawerOpen(false);

  return (
    <div className="max-w-md mx-auto h-screen flex flex-col bg-background relative overflow-hidden">
      <AppHeader 
        title={t("app.name")} 
        onMenuClick={openDrawer} 
      />

      <main className="flex-1 overflow-y-auto hide-scrollbar">
        <section className="p-4">
          {/* Wallet Dashboard */}
          <WalletDashboard
            onSend={handleSend}
            onReceive={handleReceive}
            onOffline={handleOfflineMode}
          />

          {/* Action Shortcuts */}
          <ActionShortcuts />

          {/* Education Section */}
          <EducationSection educationalItems={educationalContent || []} />

          {/* Transaction History */}
          <TransactionHistory />
        </section>
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation activePage={ROUTES.HOME} />

      {/* Side Drawer */}
      <SideDrawer isOpen={isDrawerOpen} onClose={closeDrawer} />

      {/* Modals */}
      <ReceiveModal isOpen={isReceiveModalOpen} onClose={() => setIsReceiveModalOpen(false)} />
      <SendModal isOpen={isSendModalOpen} onClose={() => setIsSendModalOpen(false)} />
      <OfflineOptionsModal isOpen={isOfflineModalOpen} onClose={() => setIsOfflineModalOpen(false)} />
    </div>
  );
}
