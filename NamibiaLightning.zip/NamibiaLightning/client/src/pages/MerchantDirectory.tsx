import { useState } from "react";
import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";
import { MERCHANT_CATEGORIES } from "@/lib/constants";
import { useQuery } from "@tanstack/react-query";
import AppHeader from "@/components/AppHeader";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import BottomNavigation from "@/components/BottomNavigation";
import { Search, MapPin, Star } from "lucide-react";
import { ROUTES } from "@/lib/constants";

export default function MerchantDirectory() {
  const [, navigate] = useLocation();
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  // Fetch all merchants
  const { data: merchants, isLoading: isLoadingMerchants } = useQuery({
    queryKey: ["/api/merchants"],
  });

  // Fetch featured merchants
  const { data: featuredMerchants, isLoading: isLoadingFeatured } = useQuery({
    queryKey: ["/api/merchants/featured"],
  });

  // Filter merchants based on search term and category
  const filteredMerchants = merchants?.filter(merchant => {
    const matchesSearch = searchTerm === "" || 
      merchant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      merchant.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === "All" || 
      merchant.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="h-screen flex flex-col bg-background">
      <AppHeader 
        title={t("merchants.title")} 
        showBackButton={true} 
        onBack={() => navigate(ROUTES.HOME)}
      />
      
      <div className="flex-1 overflow-y-auto p-4">
        {/* Search Bar */}
        <div className="relative mb-4">
          <Input
            placeholder={t("merchants.searchPlaceholder")}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        </div>
        
        {/* Category Filter */}
        <div className="flex overflow-x-auto hide-scrollbar -mx-4 px-4 mb-4">
          <div className="flex space-x-2">
            {MERCHANT_CATEGORIES.map((category) => (
              <button
                key={category}
                className={`whitespace-nowrap px-3 py-1 rounded-full text-sm ${
                  selectedCategory === category
                    ? "bg-primary text-white"
                    : "bg-gray-100 text-gray-700"
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {t(`merchants.categories.${category.toLowerCase()}`)}
              </button>
            ))}
          </div>
        </div>
        
        {/* Featured Merchants */}
        <div className="mb-4">
          <h2 className="font-poppins font-medium mb-3">{t("merchants.featured")}</h2>
          
          {isLoadingFeatured ? (
            <div className="grid grid-cols-2 gap-3">
              {[1, 2].map((i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm overflow-hidden">
                  <Skeleton className="h-24 w-full" />
                  <div className="p-3">
                    <Skeleton className="h-4 w-3/4 mb-2" />
                    <Skeleton className="h-3 w-1/2 mb-2" />
                    <Skeleton className="h-3 w-1/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {featuredMerchants?.map((merchant) => (
                <div 
                  key={merchant.id} 
                  className="bg-white rounded-xl shadow-sm overflow-hidden cursor-pointer"
                  onClick={() => {/* View merchant details */}}
                >
                  <div className="h-24 bg-gray-200 flex items-center justify-center">
                    <i className={`fas fa-${merchant.iconType} text-3xl text-gray-400`}></i>
                  </div>
                  <div className="p-3">
                    <h3 className="font-medium text-sm mb-1">{merchant.name}</h3>
                    <div className="flex items-center text-xs text-gray-500 mb-1">
                      <MapPin className="h-3 w-3 mr-1" />
                      <span>{merchant.location}</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-xs bg-accent/10 text-accent px-2 py-0.5 rounded-full">
                        <i className="fas fa-bolt text-xs mr-1"></i>
                        Lightning
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* All Merchants */}
        <div>
          <h2 className="font-poppins font-medium mb-3">{t("merchants.all")}</h2>
          
          {isLoadingMerchants ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm p-3 flex">
                  <Skeleton className="w-16 h-16 rounded-lg mr-3" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-3/4 mb-2" />
                    <Skeleton className="h-3 w-1/2 mb-2" />
                    <Skeleton className="h-3 w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : filteredMerchants?.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              {t("merchants.noMerchants")}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredMerchants?.map((merchant) => (
                <div 
                  key={merchant.id} 
                  className="bg-white rounded-xl shadow-sm p-3 flex cursor-pointer"
                  onClick={() => {/* View merchant details */}}
                >
                  <div className="w-16 h-16 bg-gray-200 rounded-lg mr-3 flex items-center justify-center">
                    <i className={`fas fa-${merchant.iconType} text-2xl text-gray-400`}></i>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-sm mb-1">{merchant.name}</h3>
                    <div className="flex items-center text-xs text-gray-500 mb-1">
                      <MapPin className="h-3 w-3 mr-1" />
                      <span>{merchant.location}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs bg-accent/10 text-accent px-2 py-0.5 rounded-full">
                        <i className="fas fa-bolt text-xs mr-1"></i>
                        Lightning
                      </span>
                      <div className="flex items-center text-sm text-gray-500">
                        <Star className="h-3 w-3 text-yellow-400 mr-1 fill-current" />
                        <span>{(merchant.rating / 10).toFixed(1)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      <BottomNavigation activePage={ROUTES.MERCHANTS} />
    </div>
  );
}
