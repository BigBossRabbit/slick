import { useState } from "react";
import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";
import { useQuery } from "@tanstack/react-query";
import AppHeader from "@/components/AppHeader";
import BottomNavigation from "@/components/BottomNavigation";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { EDUCATIONAL_CATEGORIES, ROUTES } from "@/lib/constants";
import { ChevronRight } from "lucide-react";

export default function Learn() {
  const [, navigate] = useLocation();
  const { t } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState("basics");

  // Fetch educational content
  const { data: educationalContent, isLoading } = useQuery({
    queryKey: ["/api/educational-content"],
  });

  // Filter by category
  const filteredContent = educationalContent?.filter(
    (content) => content.category === selectedCategory
  );

  return (
    <div className="h-screen flex flex-col bg-background">
      <AppHeader 
        title={t("learn.title")}
        showBackButton={true}
        onBack={() => navigate(ROUTES.HOME)}
      />
      
      <main className="flex-1 overflow-y-auto p-4">
        <Tabs defaultValue="basics" value={selectedCategory} onValueChange={setSelectedCategory}>
          <TabsList className="grid grid-cols-4 mb-4">
            {EDUCATIONAL_CATEGORIES.map((category) => (
              <TabsTrigger key={category} value={category}>
                {t(`learn.categories.${category}`)}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {EDUCATIONAL_CATEGORIES.map((category) => (
            <TabsContent key={category} value={category}>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <Card key={i}>
                      <CardContent className="p-0">
                        <Skeleton className="h-40 w-full rounded-t-lg" />
                        <div className="p-4">
                          <Skeleton className="h-6 w-3/4 mb-2" />
                          <Skeleton className="h-4 w-full mb-1" />
                          <Skeleton className="h-4 w-2/3" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : filteredContent?.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No educational content found in this category
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredContent?.map((content) => (
                    <Card key={content.id} className="overflow-hidden">
                      <CardContent className="p-0">
                        <div className={`h-40 bg-${content.backgroundColor} flex items-center justify-center`}>
                          <i className={`fas fa-${content.iconType} text-5xl text-primary`}></i>
                        </div>
                        <div className="p-4">
                          <h3 className="font-medium text-lg mb-2">{content.title}</h3>
                          <p className="text-gray-600 mb-3">{content.summary}</p>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="text-primary hover:bg-primary/10"
                          >
                            {t("learn.readMore")}
                            <ChevronRight className="h-4 w-4 ml-1" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </main>
      
      <BottomNavigation activePage={ROUTES.LEARN} />
    </div>
  );
}
