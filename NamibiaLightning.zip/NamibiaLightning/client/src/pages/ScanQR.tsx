import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";
import AppHeader from "@/components/AppHeader";
import BottomNavigation from "@/components/BottomNavigation";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ROUTES } from "@/lib/constants";
import { Camera, AlertCircle } from "lucide-react";

export default function ScanQR() {
  const [, navigate] = useLocation();
  const { t } = useLanguage();
  const [hasCamera, setHasCamera] = useState<boolean | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Check camera availability
  useEffect(() => {
    const checkCamera = async () => {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const cameras = devices.filter(device => device.kind === 'videoinput');
        setHasCamera(cameras.length > 0);
      } catch (error) {
        console.error('Error checking camera:', error);
        setHasCamera(false);
        setCameraError("Could not check camera availability");
      }
    };

    checkCamera();
  }, []);

  // Initialize camera when component mounts
  useEffect(() => {
    let stream: MediaStream | null = null;

    const startCamera = async () => {
      if (!hasCamera || !videoRef.current) return;

      try {
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: "environment" } 
        });
        videoRef.current.srcObject = stream;
        setCameraError(null);
      } catch (error) {
        console.error('Error accessing camera:', error);
        setCameraError(t("scan.error"));
      }
    };

    if (hasCamera) {
      startCamera();
    }

    // Cleanup function
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [hasCamera, t]);

  return (
    <div className="h-screen flex flex-col bg-black">
      <AppHeader 
        title={t("scan.title")}
        showBackButton={true}
        onBack={() => navigate(ROUTES.HOME)}
        darkMode={true}
      />
      
      <main className="flex-1 flex items-center justify-center">
        {hasCamera === null ? (
          <div className="text-white text-center">
            <Camera className="h-12 w-12 mx-auto mb-4 animate-pulse" />
            <p>{t("common.loading")}</p>
          </div>
        ) : hasCamera === false ? (
          <Card className="w-11/12 max-w-md mx-auto">
            <CardContent className="pt-6">
              <div className="flex mb-4 gap-2">
                <AlertCircle className="h-8 w-8 text-red-500" />
                <h1 className="text-xl font-bold text-gray-900">{t("scan.error")}</h1>
              </div>
              <p className="mt-4 text-sm text-gray-600">
                Camera not found. Please ensure your device has a camera and you've given permission to use it.
              </p>
              <Button className="w-full mt-4" onClick={() => navigate(ROUTES.HOME)}>
                {t("common.back")}
              </Button>
            </CardContent>
          </Card>
        ) : cameraError ? (
          <div className="w-11/12 max-w-md mx-auto">
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {cameraError}
              </AlertDescription>
            </Alert>
            <p className="text-white text-center mt-4">{t("scan.permission")}</p>
            <Button className="w-full mt-4" onClick={() => navigate(ROUTES.HOME)}>
              {t("common.back")}
            </Button>
          </div>
        ) : (
          <div className="relative w-full h-full">
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-64 h-64 border-4 border-white/80 rounded-lg shadow-lg" />
            </div>
            <div className="absolute bottom-20 left-0 right-0 text-center">
              <p className="text-white bg-black/50 p-3 mx-auto max-w-xs rounded-lg">
                {t("scan.instructions")}
              </p>
            </div>
          </div>
        )}
      </main>
      
      <BottomNavigation activePage={ROUTES.SCAN} darkMode={true} />
    </div>
  );
}
