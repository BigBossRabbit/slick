import { useState } from "react";
import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";
import { useWallet } from "@/hooks/useWallet";
import AppHeader from "@/components/AppHeader";
import BottomNavigation from "@/components/BottomNavigation";
import ECashMintManager from "@/components/ECashMintManager";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { APP_VERSION, ROUTES } from "@/lib/constants";
import { User, Shield, Bell, Database, HelpCircle, Info, ArrowRightLeft, Zap, Wallet } from "lucide-react";

export default function Settings() {
  const [, navigate] = useLocation();
  const { 
    t, 
    language, 
    setLanguage, 
    languages, 
    currency, 
    setCurrency, 
    currencies, 
    dataSavingMode, 
    setDataSavingMode 
  } = useLanguage();
  
  const { wallet } = useWallet();

  return (
    <div className="h-screen flex flex-col bg-background">
      <AppHeader 
        title={t("settings.title")}
        showBackButton={true}
        onBack={() => navigate(ROUTES.HOME)}
      />
      
      <main className="flex-1 overflow-y-auto p-4">
        <Card className="mb-4">
          <CardContent className="pt-6">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-white mr-3">
                <User className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium">My Wallet</h3>
                <p className="text-sm text-gray-500">Non-custodial</p>
              </div>
            </div>
            
            {wallet && (
              <div className="bg-primary/10 rounded-lg p-3 text-sm">
                <div className="flex justify-between mb-1">
                  <span className="text-gray-600">{t("wallet.balance")}:</span>
                  <span className="font-medium">{wallet.balance.toLocaleString()} {t("wallet.sats")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">{t("wallet.transactions")}:</span>
                  <span className="font-medium">3</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Tabs defaultValue="general" className="mb-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="general" className="flex items-center">
              <Wallet className="h-4 w-4 mr-2" />
              General
            </TabsTrigger>
            <TabsTrigger value="eCash" className="flex items-center">
              <Zap className="h-4 w-4 mr-2" />
              eCash Mints
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="general" className="mt-4">
            <div className="space-y-6">
              {/* Language Settings */}
              <div>
                <h2 className="text-lg font-semibold mb-2">{t("settings.language")}</h2>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Separator />
              
              {/* Currency Settings */}
              <div>
                <h2 className="text-lg font-semibold mb-2">{t("settings.currency")}</h2>
                <Select value={currency} onValueChange={setCurrency}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((curr) => (
                      <SelectItem key={curr.code} value={curr.code}>
                        {curr.code} ({curr.symbol}) - {curr.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Separator />
              
              {/* Data Saving Mode */}
              <div>
                <div className="flex justify-between items-center">
                  <div className="space-y-0.5">
                    <div className="flex items-center">
                      <Database className="h-5 w-5 mr-2 text-gray-500" />
                      <h2 className="text-lg font-semibold">{t("settings.dataSavingMode")}</h2>
                    </div>
                    <p className="text-sm text-gray-500">Minimize bandwidth usage</p>
                  </div>
                  <Switch 
                    checked={dataSavingMode} 
                    onCheckedChange={setDataSavingMode} 
                  />
                </div>
              </div>
              
              <Separator />
              
              {/* Other Settings (Not functional in MVP) */}
              <div className="space-y-3">
                <button className="w-full flex items-center p-3 rounded-lg hover:bg-gray-100 transition-colors">
                  <Shield className="h-5 w-5 mr-3 text-gray-500" />
                  <span>{t("settings.security")}</span>
                </button>
                
                <button className="w-full flex items-center p-3 rounded-lg hover:bg-gray-100 transition-colors">
                  <Bell className="h-5 w-5 mr-3 text-gray-500" />
                  <span>{t("settings.notifications")}</span>
                </button>
                
                <button className="w-full flex items-center p-3 rounded-lg hover:bg-gray-100 transition-colors">
                  <HelpCircle className="h-5 w-5 mr-3 text-gray-500" />
                  <span>{t("settings.help")}</span>
                </button>
                
                <button className="w-full flex items-center p-3 rounded-lg hover:bg-gray-100 transition-colors">
                  <Info className="h-5 w-5 mr-3 text-gray-500" />
                  <span>{t("settings.about")}</span>
                </button>
              </div>
              
              <Separator />
              
              {/* Backup Wallet */}
              <button className="w-full flex items-center justify-center p-3 bg-secondary/10 text-secondary rounded-lg font-medium">
                <ArrowRightLeft className="h-5 w-5 mr-2" />
                {t("settings.backupWallet")}
              </button>
              
              <div className="text-center text-sm text-gray-500">
                {t("settings.version")}: {APP_VERSION}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="eCash" className="mt-4">
            <ECashMintManager />
          </TabsContent>
        </Tabs>
      </main>
      
      <BottomNavigation activePage={ROUTES.SETTINGS} />
    </div>
  );
}