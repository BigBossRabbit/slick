import { useEffect } from "react";
import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";
import { X, User, ExternalLink, RefreshCw, Store, GraduationCap, Shield, Settings, HelpCircle } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ROUTES } from "@/lib/constants";

interface SideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SideDrawer({ isOpen, onClose }: SideDrawerProps) {
  const [, navigate] = useLocation();
  const { 
    t, 
    language, 
    setLanguage, 
    languages, 
    currency, 
    setCurrency, 
    currencies 
  } = useLanguage();

  // Handle clicks outside to close drawer
  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (isOpen && target.hasAttribute('data-drawer-overlay')) {
        onClose();
      }
    };

    document.addEventListener('click', handleOutsideClick);
    
    // Prevent scrolling when drawer is open
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }

    return () => {
      document.removeEventListener('click', handleOutsideClick);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  const navigateTo = (route: string) => {
    navigate(route);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 z-20 flex"
      data-drawer-overlay
    >
      <div 
        className="absolute top-0 right-0 h-full w-3/4 max-w-xs bg-white shadow-xl transform transition-transform duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-5">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-poppins text-xl font-semibold">{t("app.name")}</h2>
            <button 
              className="focus:outline-none"
              onClick={onClose}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          
          <div className="mb-6">
            <div className="bg-primary/10 rounded-xl p-4 mb-4">
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-white mr-3">
                  <User className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-medium">My Wallet</h3>
                  <p className="text-sm text-gray-500">Non-custodial</p>
                </div>
              </div>
            </div>
            
            <ul className="space-y-1">
              <li>
                <button 
                  className="w-full flex items-center p-3 rounded-lg hover:bg-gray-100 text-left"
                  onClick={() => console.log("View transaction history")}
                >
                  <RefreshCw className="w-6 h-6 text-gray-500" />
                  <span className="ml-2">Transaction History</span>
                </button>
              </li>
              <li>
                <button 
                  className="w-full flex items-center p-3 rounded-lg hover:bg-gray-100 text-left"
                  onClick={() => console.log("Open offline mode")}
                >
                  <i className="fas fa-signal w-6 text-gray-500"></i>
                  <span className="ml-2">Offline Mode</span>
                </button>
              </li>
              <li>
                <button 
                  className="w-full flex items-center p-3 rounded-lg hover:bg-gray-100 text-left"
                  onClick={() => navigateTo(ROUTES.MERCHANTS)}
                >
                  <Store className="w-6 h-6 text-gray-500" />
                  <span className="ml-2">Namibian Merchants</span>
                </button>
              </li>
              <li>
                <button 
                  className="w-full flex items-center p-3 rounded-lg hover:bg-gray-100 text-left"
                  onClick={() => navigateTo(ROUTES.LEARN)}
                >
                  <GraduationCap className="w-6 h-6 text-gray-500" />
                  <span className="ml-2">Learn About Bitcoin</span>
                </button>
              </li>
              <li>
                <button 
                  className="w-full flex items-center p-3 rounded-lg hover:bg-gray-100 text-left"
                  onClick={() => console.log("Open security settings")}
                >
                  <Shield className="w-6 h-6 text-gray-500" />
                  <span className="ml-2">Security</span>
                </button>
              </li>
              <li>
                <button 
                  className="w-full flex items-center p-3 rounded-lg hover:bg-gray-100 text-left"
                  onClick={() => navigateTo(ROUTES.SETTINGS)}
                >
                  <Settings className="w-6 h-6 text-gray-500" />
                  <span className="ml-2">Settings</span>
                </button>
              </li>
              <li>
                <button 
                  className="w-full flex items-center p-3 rounded-lg hover:bg-gray-100 text-left"
                  onClick={() => console.log("Open help & support")}
                >
                  <HelpCircle className="w-6 h-6 text-gray-500" />
                  <span className="ml-2">Help & Support</span>
                </button>
              </li>
            </ul>
          </div>
          
          <div className="border-t border-gray-200 pt-4 space-y-3">
            <div className="flex items-center">
              <span className="text-sm text-gray-500 mr-2">{t("settings.language")}:</span>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-auto h-8 text-sm px-2 border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {languages.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center">
              <span className="text-sm text-gray-500 mr-2">{t("settings.currency")}:</span>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger className="w-auto h-8 text-sm px-2 border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((curr) => (
                    <SelectItem key={curr.code} value={curr.code}>
                      {curr.code} ({curr.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="mt-8 pt-4 border-t border-gray-200">
            <button className="text-secondary font-medium flex items-center">
              <ExternalLink className="h-4 w-4 mr-2" />
              <span>{t("settings.backupWallet")}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
