import { useState, useEffect } from "react";
import { Mint } from "@shared/schema";
import { useECashContext } from "@/contexts/ECashContext";
import { useLanguageContext } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { BadgeCheck, Trash2, Edit, ExternalLink, Plus } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { useWalletContext } from "@/contexts/WalletContext";
import { SATS_PER_BTC } from "@/lib/constants";

export default function ECashMintManager() {
  const { mints, isMintsLoading, addMint, updateMint, deleteMint } = useECashContext();
  const { darkMode } = useLanguageContext();
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const { exchangeRate } = useWalletContext();
  
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [currentMint, setCurrentMint] = useState<Mint | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    url: "",
    customKeyName: "",
  });

  // Reset form when dialog opens/closes
  useEffect(() => {
    if (!isAddDialogOpen) {
      setFormData({
        name: "",
        url: "",
        customKeyName: "",
      });
    }
  }, [isAddDialogOpen]);

  // Set form data when editing a mint
  useEffect(() => {
    if (currentMint && isEditDialogOpen) {
      setFormData({
        name: currentMint.name,
        url: currentMint.url,
        customKeyName: currentMint.customKeyName || "",
      });
    }
  }, [currentMint, isEditDialogOpen]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleAddMint = async () => {
    try {
      if (!formData.name || !formData.url) {
        toast({
          title: "Please fill in required fields",
          description: "Name and URL are required",
          variant: "destructive",
        });
        return;
      }

      await addMint({
        name: formData.name,
        url: formData.url,
        customKeyName: formData.customKeyName || null,
        active: true,
        balance: 0,
      });

      toast({
        title: "Mint added",
        description: "The eCash mint has been added successfully",
      });

      setIsAddDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add mint",
        variant: "destructive",
      });
    }
  };

  const handleUpdateMint = async () => {
    try {
      if (!currentMint || !formData.name || !formData.url) {
        toast({
          title: "Please fill in required fields",
          description: "Name and URL are required",
          variant: "destructive",
        });
        return;
      }

      await updateMint(currentMint.id, {
        name: formData.name,
        url: formData.url,
        customKeyName: formData.customKeyName || null,
      });

      toast({
        title: "Mint updated",
        description: "The eCash mint has been updated successfully",
      });

      setIsEditDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update mint",
        variant: "destructive",
      });
    }
  };

  const handleDeleteMint = async (id: number) => {
    try {
      await deleteMint(id);
      toast({
        title: "Mint deleted",
        description: "The eCash mint has been deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete mint",
        variant: "destructive",
      });
    }
  };

  // Handle edit button click
  const handleEditClick = (mint: Mint) => {
    setCurrentMint(mint);
    setIsEditDialogOpen(true);
  };

  // JSX for the mint card
  const renderMintCard = (mint: Mint) => (
    <Card 
      key={mint.id} 
      className={`mb-4 ${darkMode ? 'bg-gray-800 text-white' : 'bg-white'}`}
    >
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg flex items-center">
              {mint.name}
              {mint.active && (
                <BadgeCheck className="ml-2 h-4 w-4 text-green-500" />
              )}
            </CardTitle>
            {mint.customKeyName && (
              <CardDescription>
                Alias: {mint.customKeyName}
              </CardDescription>
            )}
          </div>
          <div className="flex">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => handleEditClick(mint)}
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => handleDeleteMint(mint.id)}
            >
              <Trash2 className="h-4 w-4 text-red-500" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="text-sm flex items-center">
          <span className="mr-2">URL:</span>
          <a 
            href={mint.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-blue-500 hover:underline flex items-center"
          >
            {mint.url.length > 30 ? `${mint.url.substring(0, 30)}...` : mint.url}
            <ExternalLink className="ml-1 h-3 w-3" />
          </a>
        </div>
        <div className="mt-2 font-semibold">
          Balance: {mint.balance} sats
          <span className="text-sm ml-2 opacity-70">
            (~NAD {(mint.balance * (exchangeRate?.satoshiToNAD || 0)).toFixed(2)})
          </span>
        </div>
      </CardContent>
      <CardFooter className="text-xs text-gray-500 pt-1">
        Last updated: {new Date(mint.lastUpdated).toLocaleString()}
      </CardFooter>
    </Card>
  );

  // Loading state
  if (isMintsLoading) {
    return (
      <div className="p-4 text-center">
        <div className="animate-pulse w-full h-8 bg-gray-200 rounded mb-4"></div>
        <div className="animate-pulse w-full h-32 bg-gray-200 rounded mb-4"></div>
        <div className="animate-pulse w-full h-32 bg-gray-200 rounded"></div>
      </div>
    );
  }

  return (
    <div className="w-full p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">eCash Mints</h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" /> Add Mint
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New eCash Mint</DialogTitle>
              <DialogDescription>
                Connect to an eCash mint to store and spend bitcoin offline.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Mint Name*</Label>
                <Input
                  id="name"
                  name="name"
                  placeholder="E.g., Cashu Mint"
                  value={formData.name}
                  onChange={handleInputChange}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="url">Mint URL*</Label>
                <Input
                  id="url"
                  name="url"
                  placeholder="https://mint.example.com"
                  value={formData.url}
                  onChange={handleInputChange}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="customKeyName">Alias (Optional)</Label>
                <Input
                  id="customKeyName"
                  name="customKeyName"
                  placeholder="Personal label for this mint"
                  value={formData.customKeyName}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline">Cancel</Button>
              </DialogClose>
              <Button onClick={handleAddMint}>Save Mint</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit eCash Mint</DialogTitle>
            <DialogDescription>
              Modify the details of your eCash mint.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="editName">Mint Name*</Label>
              <Input
                id="editName"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="editUrl">Mint URL*</Label>
              <Input
                id="editUrl"
                name="url"
                value={formData.url}
                onChange={handleInputChange}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="editCustomKeyName">Alias (Optional)</Label>
              <Input
                id="editCustomKeyName"
                name="customKeyName"
                value={formData.customKeyName}
                onChange={handleInputChange}
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button onClick={handleUpdateMint}>Update Mint</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* List of Mints */}
      <div className="mt-4">
        {mints.length === 0 ? (
          <div className="text-center p-8 border rounded-lg">
            <p className="mb-4">No eCash mints configured.</p>
            <p className="text-sm text-gray-500">
              Add a mint to use eCash features for offline transactions.
            </p>
          </div>
        ) : (
          mints.map(renderMintCard)
        )}
      </div>
    </div>
  );
}