import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";
import { EducationalContent } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ROUTES } from "@/lib/constants";
import { ChevronRight } from "lucide-react";

interface EducationSectionProps {
  educationalItems: EducationalContent[];
}

export default function EducationSection({ educationalItems = [] }: EducationSectionProps) {
  const [, navigate] = useLocation();
  const { t } = useLanguage();

  const goToLearn = () => {
    navigate(ROUTES.LEARN);
  };

  return (
    <div className="mb-4">
      <div className="flex justify-between items-center mb-3">
        <h2 className="font-poppins font-medium">{t("learn.title")}</h2>
        <Button 
          variant="link" 
          className="text-primary text-sm font-medium p-0"
          onClick={goToLearn}
        >
          {t("learn.viewAll")}
        </Button>
      </div>
      
      <div className="overflow-x-auto hide-scrollbar -mx-4 px-4">
        <div className="flex space-x-3">
          {educationalItems.length === 0 ? (
            // Show skeletons while loading
            <>
              <div className="flex-shrink-0 w-64 bg-white rounded-xl overflow-hidden shadow-sm">
                <Skeleton className="h-32 w-full" />
                <div className="p-3">
                  <Skeleton className="h-5 w-3/4 mb-1" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-1/4" />
                </div>
              </div>
              <div className="flex-shrink-0 w-64 bg-white rounded-xl overflow-hidden shadow-sm">
                <Skeleton className="h-32 w-full" />
                <div className="p-3">
                  <Skeleton className="h-5 w-3/4 mb-1" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-1/4" />
                </div>
              </div>
            </>
          ) : (
            // Map through actual educational content
            educationalItems.map((item) => (
              <div key={item.id} className="flex-shrink-0 w-64 bg-white rounded-xl overflow-hidden shadow-sm">
                <div className={`h-32 bg-${item.backgroundColor} flex items-center justify-center`}>
                  <i className={`fas fa-${item.iconType} text-3xl text-primary`}></i>
                </div>
                <div className="p-3">
                  <h3 className="font-medium text-sm mb-1">{item.title}</h3>
                  <p className="text-xs text-gray-500 mb-2">{item.summary}</p>
                  <Button
                    variant="link" 
                    className="text-xs font-medium text-primary p-0 h-auto"
                    onClick={() => navigate(ROUTES.LEARN)}
                  >
                    {t("learn.readMore")}
                    <ChevronRight className="h-3 w-3 ml-1" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
