import { useLanguage } from "@/hooks/useLanguage";
import { useWallet } from "@/hooks/useWallet";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Send, QrCode, Wifi, Loader2, Zap } from "lucide-react";

interface WalletDashboardProps {
  onSend: () => void;
  onReceive: () => void;
  onOffline: () => void;
  onECash?: () => void;
}

export default function WalletDashboard({ 
  onSend, 
  onReceive, 
  onOffline,
  onECash
}: WalletDashboardProps) {
  const { t } = useLanguage();
  const { 
    wallet, 
    isWalletLoading, 
    formattedSatoshiBalance, 
    formattedBtcBalance, 
    formattedFiatBalance 
  } = useWallet();

  return (
    <div className="bg-white rounded-xl shadow-md p-5 mb-4">
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-sm font-medium text-gray-500">{t("wallet.yourBalance")}</h2>
        <div className="flex items-center">
          <span className="text-xs bg-accent/10 text-accent px-2 py-1 rounded-full font-medium">
            <i className="fas fa-bolt text-xs mr-1"></i>
            {t("wallet.lightning")}
          </span>
        </div>
      </div>
      
      {isWalletLoading ? (
        <>
          <Skeleton className="h-9 w-3/4 mb-2" />
          <Skeleton className="h-4 w-1/2 mb-4" />
        </>
      ) : (
        <>
          <div className="flex items-baseline mb-1">
            <span className="text-3xl font-semibold font-poppins">{formattedSatoshiBalance}</span>
            <span className="text-lg ml-1 font-medium text-gray-600">{t("wallet.sats")}</span>
          </div>
          
          <div className="flex items-center text-gray-500 text-sm mb-4">
            <span>{formattedBtcBalance}</span>
            <span className="mx-2">•</span>
            <span>{formattedFiatBalance}</span>
          </div>
        </>
      )}
      
      <div className="grid grid-cols-4 gap-2">
        <Button 
          className="flex flex-col items-center justify-center h-20 bg-primary text-white p-3 rounded-lg"
          onClick={onSend}
          disabled={isWalletLoading}
        >
          <div className="flex flex-col items-center justify-center h-full">
            {isWalletLoading ? (
              <Loader2 className="h-5 w-5 animate-spin mb-1" />
            ) : (
              <Send className="h-5 w-5 mb-1" />
            )}
            <span className="text-xs font-medium">{t("common.send")}</span>
          </div>
        </Button>
        
        <Button 
          className="flex flex-col items-center justify-center h-20 bg-primary text-white p-3 rounded-lg"
          onClick={onReceive}
          disabled={isWalletLoading}
        >
          <div className="flex flex-col items-center justify-center h-full">
            {isWalletLoading ? (
              <Loader2 className="h-5 w-5 animate-spin mb-1" />
            ) : (
              <QrCode className="h-5 w-5 mb-1" />
            )}
            <span className="text-xs font-medium">{t("common.receive")}</span>
          </div>
        </Button>
        
        <Button 
          className="flex flex-col items-center justify-center h-20 bg-yellow-500 text-white p-3 rounded-lg"
          onClick={onECash}
          disabled={isWalletLoading}
        >
          <div className="flex flex-col items-center justify-center h-full">
            {isWalletLoading ? (
              <Loader2 className="h-5 w-5 animate-spin mb-1" />
            ) : (
              <Zap className="h-5 w-5 mb-1" />
            )}
            <span className="text-xs font-medium">eCash</span>
          </div>
        </Button>
        
        <Button 
          variant="outline"
          className="flex flex-col items-center justify-center h-20 bg-gray-200 text-gray-700 p-3 rounded-lg"
          onClick={onOffline}
          disabled={isWalletLoading}
        >
          <div className="flex flex-col items-center justify-center h-full">
            {isWalletLoading ? (
              <Loader2 className="h-5 w-5 animate-spin mb-1" />
            ) : (
              <Wifi className="h-5 w-5 mb-1" />
            )}
            <span className="text-xs font-medium">{t("common.offline")}</span>
          </div>
        </Button>
      </div>
    </div>
  );
}
