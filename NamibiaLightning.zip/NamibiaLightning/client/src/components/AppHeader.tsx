import { useState } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { Bell, Menu, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useLanguageContext } from "@/contexts/LanguageContext";

interface AppHeaderProps {
  title: string;
  showBackButton?: boolean;
  onBack?: () => void;
  onMenuClick?: () => void;
  darkMode?: boolean;
}

export default function AppHeader({
  title,
  showBackButton = false,
  onBack,
  onMenuClick,
  darkMode = false
}: AppHeaderProps) {
  const { t } = useLanguage();
  const { darkMode: isDarkMode, setDarkMode } = useLanguageContext();
  const [showNotifications, setShowNotifications] = useState(false);
  
  const toggleNotifications = () => {
    setShowNotifications(!showNotifications);
  };
  
  const toggleDarkMode = () => {
    setDarkMode(!isDarkMode);
  };

  return (
    <header className={cn(
      "p-4 flex items-center justify-between sticky top-0 z-10",
      isDarkMode ? "bg-black text-white" : "bg-primary text-white"
    )}>
      <div className="flex items-center">
        {showBackButton ? (
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="mr-2 text-white hover:bg-white/10"
          >
            <i className="fas fa-arrow-left text-lg"></i>
          </Button>
        ) : (
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleDarkMode}
            className="mr-2 text-white hover:bg-white/10"
          >
            {isDarkMode ? (
              <Moon className="h-5 w-5" />
            ) : (
              <Sun className="h-5 w-5" />
            )}
          </Button>
        )}
        <h1 className="font-poppins text-xl font-semibold">{title}</h1>
      </div>
      <div className="flex items-center space-x-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleNotifications}
          className="text-white hover:bg-white/10"
        >
          <Bell className="h-5 w-5" />
        </Button>
        {onMenuClick && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onMenuClick}
            className="text-white hover:bg-white/10"
          >
            <Menu className="h-5 w-5" />
          </Button>
        )}
      </div>
    </header>
  );
}
