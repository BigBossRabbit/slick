import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";
import { ROUTES } from "@/lib/constants";
import { Zap, Store } from "lucide-react";

export default function ActionShortcuts() {
  const [, navigate] = useLocation();
  const { t } = useLanguage();

  const handleMachankuraClick = () => {
    // Navigate to offline options or open the modal
    window.open('https://web.8333.mobi/', '_blank');
  };

  const handleMerchantsClick = () => {
    navigate(ROUTES.MERCHANTS);
  };

  return (
    <div className="grid grid-cols-2 gap-3 mb-4">
      <div 
        className="bg-white rounded-xl p-4 shadow-sm flex items-center cursor-pointer"
        onClick={handleMachankuraClick}
      >
        <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center mr-3">
          <Zap className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h3 className="text-sm font-medium">Machankura</h3>
          <p className="text-xs text-gray-500">Offline payments</p>
        </div>
      </div>
      
      <div 
        className="bg-white rounded-xl p-4 shadow-sm flex items-center cursor-pointer"
        onClick={handleMerchantsClick}
      >
        <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center mr-3">
          <Store className="h-5 w-5 text-secondary" />
        </div>
        <div>
          <h3 className="text-sm font-medium">{t("common.merchants")}</h3>
          <p className="text-xs text-gray-500">Local businesses</p>
        </div>
      </div>
    </div>
  );
}
