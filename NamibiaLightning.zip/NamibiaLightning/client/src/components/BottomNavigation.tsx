import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";
import { ROUTES } from "@/lib/constants";
import { Wallet, QrCode, Store, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

interface BottomNavigationProps {
  activePage: string;
  darkMode?: boolean;
}

export default function BottomNavigation({ activePage, darkMode = false }: BottomNavigationProps) {
  const [, navigate] = useLocation();
  const { t } = useLanguage();

  const navItems = [
    {
      label: t("common.wallet"),
      icon: Wallet,
      route: ROUTES.HOME,
    },
    {
      label: t("common.scan"),
      icon: QrCode,
      route: ROUTES.SCAN,
    },
    {
      label: t("common.merchants"),
      icon: Store,
      route: ROUTES.MERCHANTS,
    },
    {
      label: t("common.settings"),
      icon: Settings,
      route: ROUTES.SETTINGS,
    },
  ];

  return (
    <nav className={cn(
      "border-t border-gray-200 flex justify-around items-center py-2 px-4 sticky bottom-0 z-10",
      darkMode ? "bg-black border-gray-800" : "bg-white"
    )}>
      {navItems.map((item) => {
        const isActive = activePage === item.route;
        return (
          <button
            key={item.route}
            className={cn(
              "flex flex-col items-center justify-center py-1 px-3",
              isActive 
                ? "text-primary" 
                : darkMode ? "text-gray-500" : "text-gray-400"
            )}
            onClick={() => navigate(item.route)}
          >
            <item.icon className="text-lg h-5 w-5" />
            <span className="text-xs mt-1 font-medium">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
