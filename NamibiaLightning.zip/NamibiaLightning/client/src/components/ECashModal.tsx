import { useState, useEffect } from "react";
import { X, Download, Upload, Copy, CheckCircle, RefreshCw } from "lucide-react";
import { useECashContext } from "@/contexts/ECashContext";
import { useLanguageContext } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ECashModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ECashModal({ isOpen, onClose }: ECashModalProps) {
  const { mints, activeMint, setActiveMint } = useECashContext();
  const { darkMode } = useLanguageContext();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState("send");
  const [token, setToken] = useState("");
  const [amount, setAmount] = useState<number | "">("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  
  // Reset state when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      setToken("");
      setAmount("");
      setNote("");
      setCopied(false);
      setLoading(false);
      setActiveTab("send");
    }
  }, [isOpen]);
  
  if (!isOpen) return null;
  
  const handleSelectMint = (mintId: string) => {
    const selected = mints.find(mint => mint.id.toString() === mintId);
    setActiveMint(selected || null);
  };
  
  const handleSend = async () => {
    if (!activeMint) {
      toast({
        title: "No mint selected",
        description: "Please select an eCash mint first",
        variant: "destructive",
      });
      return;
    }
    
    if (!token) {
      toast({
        title: "Missing token",
        description: "Please enter a valid eCash token",
        variant: "destructive",
      });
      return;
    }
    
    setLoading(true);
    
    // This is just a simulated action since we don't have real eCash integration yet
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "eCash sent successfully",
        description: "The eCash payment has been completed",
      });
      onClose();
    }, 1500);
  };
  
  const handleReceive = async () => {
    if (!activeMint) {
      toast({
        title: "No mint selected",
        description: "Please select an eCash mint first",
        variant: "destructive",
      });
      return;
    }
    
    if (!amount || amount <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }
    
    setLoading(true);
    
    // This is just a simulated action since we don't have real eCash integration yet
    setTimeout(() => {
      setLoading(false);
      setToken("ecash1234abcd5678efgh9012ijkl3456mnop7890qrst");
    }, 1500);
  };
  
  const handleCopy = () => {
    if (token) {
      navigator.clipboard.writeText(token);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
      
      toast({
        title: "Copied to clipboard",
        description: "eCash token copied to clipboard",
      });
    }
  };
  
  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 ${darkMode ? 'bg-gray-900/80' : 'bg-gray-500/80'}`}>
      <div className={`relative w-full max-w-md rounded-lg shadow-lg ${darkMode ? 'bg-gray-800 text-white' : 'bg-white'} p-6`}>
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-4 top-4"
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
        
        <h2 className="text-xl font-bold mb-4">eCash Wallet</h2>
        
        {/* Mint selector */}
        <div className="mb-4">
          <Label htmlFor="mintSelect">Select eCash Mint</Label>
          <Select
            value={activeMint ? activeMint.id.toString() : ""}
            onValueChange={handleSelectMint}
          >
            <SelectTrigger id="mintSelect" className="w-full mt-1">
              <SelectValue placeholder="Select a mint" />
            </SelectTrigger>
            <SelectContent>
              {mints.length === 0 ? (
                <SelectItem value="none" disabled>
                  No mints available (add in Settings)
                </SelectItem>
              ) : (
                mints.map(mint => (
                  <SelectItem key={mint.id} value={mint.id.toString()}>
                    {mint.name} ({mint.balance} sats)
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        </div>
        
        {activeMint && (
          <>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="send" className="flex items-center">
                  <Upload className="h-4 w-4 mr-2" />
                  Send
                </TabsTrigger>
                <TabsTrigger value="receive" className="flex items-center">
                  <Download className="h-4 w-4 mr-2" />
                  Receive
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="send" className="mt-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="token">eCash Token</Label>
                    <Input
                      id="token"
                      value={token}
                      onChange={(e) => setToken(e.target.value)}
                      placeholder="Paste eCash token here"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="note">Note (optional)</Label>
                    <Input
                      id="note"
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="What's this payment for?"
                      className="mt-1"
                    />
                  </div>
                  
                  <Button
                    className="w-full"
                    onClick={handleSend}
                    disabled={loading || !token}
                  >
                    {loading ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      "Send eCash"
                    )}
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="receive" className="mt-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="amount">Amount (sats)</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value === "" ? "" : Number(e.target.value))}
                      placeholder="Enter amount"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="receiveNote">Note (optional)</Label>
                    <Input
                      id="receiveNote"
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="What's this payment for?"
                      className="mt-1"
                    />
                  </div>
                  
                  {token ? (
                    <div className="mt-4">
                      <Label>Your eCash Token</Label>
                      <div className={`mt-1 p-3 rounded border ${darkMode ? 'border-gray-600 bg-gray-700' : 'border-gray-300 bg-gray-50'} flex items-start`}>
                        <div className="flex-1 break-all">
                          {token}
                        </div>
                        <button
                          onClick={handleCopy}
                          className="ml-2 flex-shrink-0 text-blue-500 hover:text-blue-600"
                          title="Copy to clipboard"
                        >
                          {copied ? (
                            <CheckCircle className="h-5 w-5" />
                          ) : (
                            <Copy className="h-5 w-5" />
                          )}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <Button
                      className="w-full"
                      onClick={handleReceive}
                      disabled={loading || amount === "" || typeof amount === "number" && amount <= 0}
                    >
                      {loading ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Generating token...
                        </>
                      ) : (
                        "Get eCash Token"
                      )}
                    </Button>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}
        
        {mints.length === 0 && (
          <div className="text-center p-4 mt-2">
            <p className="mb-2">No eCash mints configured</p>
            <p className="text-sm text-gray-500 mb-4">
              Add a mint in Settings → eCash Mints tab to use this feature
            </p>
          </div>
        )}
      </div>
    </div>
  );
}