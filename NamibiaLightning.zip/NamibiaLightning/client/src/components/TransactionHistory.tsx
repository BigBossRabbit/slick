import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";
import { useWallet } from "@/hooks/useWallet";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowUp, ArrowDown, RefreshCw } from "lucide-react";

export default function TransactionHistory() {
  const [, navigate] = useLocation();
  const { t } = useLanguage();
  const { transactions, isTransactionsLoading } = useWallet();

  // Show only the 3 most recent transactions
  const recentTransactions = transactions.slice(0, 3);

  const handleViewAllTransactions = () => {
    // In a complete implementation, we would navigate to a transactions page
    // For now, just log that we would navigate
    console.log("Navigate to all transactions");
  };

  const handleViewTransactionDetails = (transactionId: number) => {
    // In a complete implementation, we would navigate to the transaction details
    // For now, just log that we would view details of a specific transaction
    console.log(`View transaction details for ${transactionId}`);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-3">
        <h2 className="font-poppins font-medium">{t("wallet.recentTransactions")}</h2>
        <Button 
          variant="link" 
          className="text-primary text-sm font-medium p-0"
          onClick={handleViewAllTransactions}
        >
          {t("wallet.viewAll")}
        </Button>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {isTransactionsLoading ? (
          // Loading skeletons
          <>
            {[1, 2, 3].map((i) => (
              <div key={i} className="p-4 border-b border-gray-100">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <Skeleton className="w-10 h-10 rounded-full mr-3" />
                    <div>
                      <Skeleton className="h-4 w-20 mb-1" />
                      <Skeleton className="h-3 w-32" />
                    </div>
                  </div>
                  <div className="text-right">
                    <Skeleton className="h-4 w-16 mb-1" />
                    <Skeleton className="h-3 w-12" />
                  </div>
                </div>
              </div>
            ))}
          </>
        ) : recentTransactions.length === 0 ? (
          // Empty state
          <div className="p-8 text-center">
            <div className="flex justify-center mb-3">
              <RefreshCw className="h-12 w-12 text-gray-300" />
            </div>
            <p className="text-gray-500">{t("wallet.emptyTransactions")}</p>
          </div>
        ) : (
          // Transaction list
          recentTransactions.map((transaction, index) => (
            <div 
              key={transaction.id} 
              className={`p-4 ${
                index !== recentTransactions.length - 1 ? "border-b border-gray-100" : ""
              }`}
              onClick={() => handleViewTransactionDetails(transaction.id)}
            >
              <div className="flex justify-between items-center cursor-pointer">
                <div className="flex items-center">
                  <div className={`w-10 h-10 rounded-full ${
                    transaction.type === "receive" 
                      ? "bg-green-100" 
                      : transaction.type === "offline" 
                        ? "bg-accent/10" 
                        : "bg-primary/10"
                  } flex items-center justify-center mr-3`}>
                    {transaction.type === "receive" ? (
                      <ArrowDown className="h-5 w-5 text-green-600" />
                    ) : transaction.type === "offline" ? (
                      <i className="fas fa-exchange-alt text-accent"></i>
                    ) : (
                      <ArrowUp className="h-5 w-5 text-primary" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-sm font-medium">
                      {transaction.type === "receive" 
                        ? t("wallet.receivedPayment") 
                        : transaction.type === "offline"
                          ? "Offline Payment via Machankura"
                          : t("wallet.sentPayment")
                      }
                    </h3>
                    <p className="text-xs text-gray-500">
                      {transaction.formattedDate} • {transaction.formattedTime}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-medium ${
                    transaction.type === "receive" ? "text-green-600" : ""
                  }`}>
                    {transaction.formattedAmount}
                  </p>
                  <p className="text-xs text-gray-500">{transaction.formattedFiatAmount}</p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
