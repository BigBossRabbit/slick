import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useLanguage } from "@/hooks/useLanguage";
import { useWallet } from "@/hooks/useWallet";
import { useCurrencyConverter } from "@/hooks/useCurrencyConverter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { QrCode, Clipboard, Lightbulb, Loader2 } from "lucide-react";
import { ROUTES } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";

interface SendModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SendModal({ isOpen, onClose }: SendModalProps) {
  const [, navigate] = useLocation();
  const { t } = useLanguage();
  const { wallet, sendPayment } = useWallet();
  const { toast } = useToast();
  const [invoice, setInvoice] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { setInputAmount, formattedOutput } = useCurrencyConverter();

  // Reset form when modal opens
  useEffect(() => {
    if (isOpen) {
      setInvoice("");
      setAmount("");
      setDescription("");
      setIsSubmitting(false);
    }
  }, [isOpen]);

  // Update fiat conversion when amount changes
  useEffect(() => {
    setInputAmount(amount ? parseInt(amount) : null);
  }, [amount, setInputAmount]);

  const handleScanQRCode = () => {
    onClose();
    navigate(ROUTES.SCAN);
  };

  const handlePasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setInvoice(text);
      toast({
        title: "Pasted",
        description: "Invoice pasted from clipboard",
      });
    } catch (error) {
      toast({
        title: "Failed to paste",
        description: "Could not access clipboard",
        variant: "destructive",
      });
    }
  };

  const handleSendPayment = async () => {
    if (!invoice) {
      toast({
        title: "Invalid Invoice",
        description: "Please enter a valid lightning invoice",
        variant: "destructive",
      });
      return;
    }

    if (!amount || parseInt(amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }

    // Check if there are sufficient funds
    if (wallet && parseInt(amount) > wallet.balance) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough funds for this transaction",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const success = await sendPayment(invoice, parseInt(amount), description);
      if (success) {
        onClose();
      }
    } catch (error) {
      toast({
        title: "Payment Failed",
        description: "Please try again later",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Calculate if form is valid to enable/disable submit button
  const isFormValid = invoice.trim() !== "" && amount !== "" && parseInt(amount) > 0 && !isSubmitting;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-30 flex items-center justify-center" onClick={!isSubmitting ? onClose : undefined}>
      <div className="bg-white rounded-xl w-11/12 max-w-md mx-auto shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="p-5">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-poppins text-lg font-semibold">{t("send.title")}</h2>
            <button 
              className="focus:outline-none text-gray-500 hover:text-gray-700"
              onClick={onClose}
              disabled={isSubmitting}
              aria-label="Close"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide-x">
                <path d="M18 6 6 18"></path>
                <path d="m6 6 12 12"></path>
              </svg>
            </button>
          </div>
          
          <div className="bg-gray-100 rounded-xl p-4 mb-4">
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              {t("send.lightningInvoice")}
            </Label>
            <div className="flex items-center bg-white rounded-lg border border-gray-300 overflow-hidden mb-2">
              <Input
                type="text"
                placeholder={t("send.enterInvoice")}
                className="border-0 flex-1"
                value={invoice}
                onChange={(e) => setInvoice(e.target.value)}
                disabled={isSubmitting}
              />
              <button 
                className="bg-gray-100 h-full px-3 border-l border-gray-300"
                onClick={handleScanQRCode}
                disabled={isSubmitting}
              >
                <QrCode className="h-5 w-5 text-gray-600" />
              </button>
            </div>
            
            <div className="flex justify-end">
              <Button
                variant="link"
                className="p-0 h-auto text-primary text-sm font-medium"
                onClick={handlePasteFromClipboard}
                disabled={isSubmitting}
              >
                <Clipboard className="h-3 w-3 mr-1" />
                {t("send.pasteFromClipboard")}
              </Button>
            </div>
          </div>
          
          <div className="mb-4">
            <Label className="block text-sm font-medium text-gray-700 mb-1">
              {t("send.amount")}
            </Label>
            <div className="flex rounded-lg overflow-hidden border border-gray-300">
              <Input
                type="number"
                placeholder="0"
                className="border-0 flex-1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                disabled={isSubmitting}
              />
              <div className="bg-gray-100 px-3 flex items-center border-l border-gray-300">
                <span className="text-sm text-gray-600">{t("wallet.sats")}</span>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-1">≈ {formattedOutput()}</p>
          </div>
          
          <div className="mb-4">
            <Label className="block text-sm font-medium text-gray-700 mb-1">
              {t("send.description")}
            </Label>
            <Input
              type="text"
              placeholder={t("send.descriptionPlaceholder")}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              disabled={isSubmitting}
            />
          </div>
          
          <div className="mb-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">{t("send.transactionFee")}</span>
              <span className="text-sm font-medium">~1 sat</span>
            </div>
            <div className="mt-2 flex items-center justify-between">
              <span className="text-sm text-gray-600">{t("send.totalAmount")}</span>
              <span className="text-sm font-medium">
                {amount ? `${parseInt(amount) + 1} sats (${formattedOutput()})` : "0 sats"}
              </span>
            </div>
          </div>
          
          <div className="bg-accent/10 p-3 rounded-lg mb-4">
            <div className="flex items-start">
              <Lightbulb className="h-4 w-4 text-accent mt-1 mr-2 flex-shrink-0" />
              <p className="text-xs">{t("send.offlinePaymentTip")}</p>
            </div>
          </div>
          
          <Button 
            className="w-full bg-primary text-white"
            disabled={!isFormValid}
            onClick={handleSendPayment}
          >
            {isSubmitting ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : null}
            {t("send.sendPayment")}
          </Button>
        </div>
      </div>
    </div>
  );
}
