import { useLanguage } from "@/hooks/useLanguage";
import { Button } from "@/components/ui/button";
import { X, MessageSquare, Phone, Ticket, Gauge } from "lucide-react";
import { machankura } from "@/lib/machankura";

interface OfflineOptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function OfflineOptionsModal({ isOpen, onClose }: OfflineOptionsModalProps) {
  const { t } = useLanguage();

  const handleSMSOption = () => {
    // Open SMS app with Machankura number
    const smsInstructions = machankura.generateSmsInstructions(1000);
    alert(`SMS Payment Instructions: ${smsInstructions}`);
    onClose();
  };

  const handleUSSDOption = () => {
    // Generate USSD code
    const ussdCode = machankura.generateUssdCode(1000);
    alert(`USSD Code: ${ussdCode}`);
    onClose();
  };

  const handleVoucherOption = async () => {
    try {
      const voucher = await machankura.generateVoucher(1000);
      alert(`Generated voucher: ${voucher}`);
      onClose();
    } catch (error) {
      console.error("Error generating voucher:", error);
    }
  };

  const handleLowDataOption = () => {
    // Open Machankura in low data mode
    window.open(machankura.getLowDataModeUrl(), '_blank');
    onClose();
  };

  const handleLearnMore = () => {
    window.open(machankura.getWebUrl(), '_blank');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-30 flex items-center justify-center">
      <div className="bg-white rounded-xl w-11/12 max-w-md mx-auto shadow-xl">
        <div className="p-5">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-poppins text-lg font-semibold">{t("offline.title")}</h2>
            <button 
              className="focus:outline-none"
              onClick={onClose}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          
          <p className="text-sm text-gray-600 mb-4">{t("offline.subtitle")}</p>
          
          <div className="space-y-3 mb-4">
            <button 
              className="w-full flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
              onClick={handleSMSOption}
            >
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <MessageSquare className="h-5 w-5 text-primary" />
              </div>
              <div className="text-left">
                <h3 className="font-medium text-sm">{t("offline.smsTransaction")}</h3>
                <p className="text-xs text-gray-500">{t("offline.smsDescription")}</p>
              </div>
            </button>
            
            <button 
              className="w-full flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
              onClick={handleUSSDOption}
            >
              <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center mr-3">
                <Phone className="h-5 w-5 text-secondary" />
              </div>
              <div className="text-left">
                <h3 className="font-medium text-sm">{t("offline.ussdCode")}</h3>
                <p className="text-xs text-gray-500">{t("offline.ussdDescription")}</p>
              </div>
            </button>
            
            <button 
              className="w-full flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
              onClick={handleVoucherOption}
            >
              <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center mr-3">
                <Ticket className="h-5 w-5 text-accent" />
              </div>
              <div className="text-left">
                <h3 className="font-medium text-sm">{t("offline.voucherSystem")}</h3>
                <p className="text-xs text-gray-500">{t("offline.voucherDescription")}</p>
              </div>
            </button>
            
            <button 
              className="w-full flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50"
              onClick={handleLowDataOption}
            >
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
                <Gauge className="h-5 w-5 text-green-600" />
              </div>
              <div className="text-left">
                <h3 className="font-medium text-sm">{t("offline.lowDataMode")}</h3>
                <p className="text-xs text-gray-500">{t("offline.lowDataDescription")}</p>
              </div>
            </button>
          </div>
          
          <div className="bg-primary/10 p-4 rounded-lg">
            <h3 className="font-medium text-sm mb-1">{t("offline.aboutMachankura")}</h3>
            <p className="text-xs text-gray-600 mb-2">{t("offline.machankuraDescription")}</p>
            <Button
              variant="link"
              className="p-0 h-auto text-primary text-xs font-medium"
              onClick={handleLearnMore}
            >
              {t("offline.learnMore")}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
