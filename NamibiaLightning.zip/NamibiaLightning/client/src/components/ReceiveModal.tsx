import { useState, useEffect } from "react";
import { useLanguage } from "@/hooks/useLanguage";
import { useWallet } from "@/hooks/useWallet";
import { useCurrencyConverter } from "@/hooks/useCurrencyConverter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { X, Copy, Share, Lightbulb } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ReceiveModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ReceiveModal({ isOpen, onClose }: ReceiveModalProps) {
  const { t } = useLanguage();
  const { generateInvoice } = useWallet();
  const { toast } = useToast();
  const [invoice, setInvoice] = useState<string | null>(null);
  const [amount, setAmount] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const { setInputAmount, inputType, formattedOutput } = useCurrencyConverter();

  // Generate a new invoice when the modal opens
  useEffect(() => {
    if (isOpen) {
      handleGenerateNewInvoice();
    }
  }, [isOpen]);

  // Update fiat conversion when amount changes
  useEffect(() => {
    setInputAmount(amount ? parseInt(amount) : null);
  }, [amount, setInputAmount]);

  const handleGenerateNewInvoice = async () => {
    const amountValue = amount ? parseInt(amount) : undefined;
    const newInvoice = await generateInvoice(amountValue, description);
    setInvoice(newInvoice);
  };

  const handleCopyInvoice = () => {
    if (invoice) {
      navigator.clipboard.writeText(invoice)
        .then(() => {
          toast({
            title: "Copied",
            description: "Invoice copied to clipboard",
          });
        })
        .catch(() => {
          toast({
            title: "Failed to copy",
            description: "Could not copy to clipboard",
            variant: "destructive",
          });
        });
    }
  };

  const handleShareInvoice = () => {
    if (navigator.share && invoice) {
      navigator.share({
        title: 'Bitcoin Lightning Invoice',
        text: invoice,
      }).catch((error) => {
        console.error("Error sharing:", error);
      });
    } else {
      handleCopyInvoice();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-30 flex items-center justify-center" onClick={onClose}>
      <div className="bg-white rounded-xl w-11/12 max-w-md mx-auto shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="p-5">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-poppins text-lg font-semibold">{t("receive.title")}</h2>
            <button 
              className="focus:outline-none text-gray-500 hover:text-gray-700"
              onClick={onClose}
              aria-label="Close"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide-x">
                <path d="M18 6 6 18"></path>
                <path d="m6 6 12 12"></path>
              </svg>
            </button>
          </div>
          
          <div className="bg-gray-100 rounded-xl p-4 mb-4 flex flex-col items-center">
            <div className="bg-white p-4 rounded-xl mb-3">
              {/* In a real implementation, this would be a QR code generated from the invoice */}
              <div className="w-48 h-48 mx-auto bg-gray-200 flex items-center justify-center">
                {invoice ? (
                  <svg 
                    viewBox="0 0 100 100" 
                    className="w-full h-full"
                    style={{ transform: "scale(0.8)" }}
                  >
                    <rect x="0" y="0" width="100" height="100" fill="white" />
                    <path d="M10,10 L30,10 L30,30 L10,30 Z" fill="black" />
                    <path d="M35,10 L45,10 L45,30 L35,30 Z" fill="black" />
                    <path d="M50,10 L70,10 L70,20 L50,20 Z" fill="black" />
                    <path d="M75,10 L90,10 L90,30 L75,30 Z" fill="black" />
                    <path d="M10,35 L20,35 L20,55 L10,55 Z" fill="black" />
                    <path d="M25,35 L45,35 L45,45 L25,45 Z" fill="black" />
                    <path d="M50,25 L60,25 L60,55 L50,55 Z" fill="black" />
                    <path d="M65,35 L90,35 L90,45 L65,45 Z" fill="black" />
                    <path d="M10,60 L30,60 L30,90 L10,90 Z" fill="black" />
                    <path d="M35,50 L45,50 L45,70 L35,70 Z" fill="black" />
                    <path d="M50,60 L70,60 L70,80 L50,80 Z" fill="black" />
                    <path d="M75,50 L90,50 L90,90 L75,90 Z" fill="black" />
                  </svg>
                ) : (
                  <i className="fas fa-qrcode text-6xl text-gray-400"></i>
                )}
              </div>
            </div>
            
            <p className="text-sm text-center mb-2">{t("receive.lightningInvoice")}</p>
            <p className="text-xs text-gray-500 text-center break-all mb-3">
              {invoice || "..."}
            </p>
            
            <div className="flex space-x-2">
              <Button
                className="bg-primary text-white"
                size="sm"
                onClick={handleCopyInvoice}
              >
                <Copy className="h-4 w-4 mr-1" /> {t("common.copy")}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleShareInvoice}
              >
                <Share className="h-4 w-4 mr-1" /> {t("common.share")}
              </Button>
            </div>
          </div>
          
          <div className="mb-4">
            <Label className="block text-sm font-medium text-gray-700 mb-1">
              {t("receive.amount")}
            </Label>
            <div className="flex rounded-lg overflow-hidden border border-gray-300">
              <Input
                type="number"
                placeholder="0"
                className="border-0 flex-1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <div className="bg-gray-100 px-3 flex items-center border-l border-gray-300">
                <span className="text-sm text-gray-600">{t("wallet.sats")}</span>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-1">≈ {formattedOutput()}</p>
          </div>
          
          <div className="mb-4">
            <Label className="block text-sm font-medium text-gray-700 mb-1">
              {t("receive.description")}
            </Label>
            <Input
              type="text"
              placeholder={t("receive.descriptionPlaceholder")}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          
          <div className="bg-accent/10 p-3 rounded-lg mb-4">
            <div className="flex items-start">
              <Lightbulb className="h-4 w-4 text-accent mt-1 mr-2 flex-shrink-0" />
              <p className="text-xs">{t("receive.offlinePaymentTip")}</p>
            </div>
          </div>
          
          <Button 
            className="w-full bg-primary text-white"
            onClick={handleGenerateNewInvoice}
          >
            {t("receive.generateNewInvoice")}
          </Button>
        </div>
      </div>
    </div>
  );
}
