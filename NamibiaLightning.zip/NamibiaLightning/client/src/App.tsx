import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import MerchantDirectory from "@/pages/MerchantDirectory";
import Settings from "@/pages/Settings";
import Learn from "@/pages/Learn";
import ScanQR from "@/pages/ScanQR";
import { useEffect } from "react";
import { WalletProvider } from "./contexts/WalletContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import { ECashProvider } from "./contexts/ECashContext";

function AppRouter() {
  const [location] = useLocation();

  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/merchants" component={MerchantDirectory} />
      <Route path="/scan" component={ScanQR} />
      <Route path="/settings" component={Settings} />
      <Route path="/learn" component={Learn} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <WalletProvider>
          <ECashProvider>
            <TooltipProvider>
              <Toaster />
              <AppRouter />
            </TooltipProvider>
          </ECashProvider>
        </WalletProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
