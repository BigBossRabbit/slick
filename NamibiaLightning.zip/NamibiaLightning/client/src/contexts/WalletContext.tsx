import { createContext, useCallback, useContext, useState, ReactNode } from "react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Transaction, Wallet } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface WalletContextType {
  wallet: Wallet | null;
  isWalletLoading: boolean;
  transactions: Transaction[];
  isTransactionsLoading: boolean;
  exchangeRate: { satoshiToNAD: number; lastUpdated: string } | null;
  isExchangeRateLoading: boolean;
  fetchWalletData: () => Promise<void>;
  sendPayment: (invoice: string, amount: number, description?: string) => Promise<boolean>;
  generateInvoice: (amount?: number, description?: string) => Promise<string | null>;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [isWalletLoading, setIsWalletLoading] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isTransactionsLoading, setIsTransactionsLoading] = useState(false);
  const [exchangeRate, setExchangeRate] = useState<{ satoshiToNAD: number; lastUpdated: string } | null>(null);
  const [isExchangeRateLoading, setIsExchangeRateLoading] = useState(false);

  const { toast } = useToast();

  const fetchWalletData = useCallback(async () => {
    try {
      // Fetch wallet
      setIsWalletLoading(true);
      const walletResponse = await fetch("/api/wallet", {
        credentials: "include",
      });
      
      if (walletResponse.ok) {
        const walletData = await walletResponse.json();
        setWallet(walletData);
      } else {
        toast({
          title: "Failed to load wallet",
          description: "Please try again later",
          variant: "destructive",
        });
      }
      
      // Fetch transactions
      setIsTransactionsLoading(true);
      const transactionsResponse = await fetch("/api/wallet/transactions", {
        credentials: "include",
      });
      
      if (transactionsResponse.ok) {
        const transactionsData = await transactionsResponse.json();
        setTransactions(transactionsData);
      } else {
        toast({
          title: "Failed to load transactions",
          description: "Please try again later",
          variant: "destructive",
        });
      }
      
      // Fetch exchange rate
      setIsExchangeRateLoading(true);
      const exchangeRateResponse = await fetch("/api/exchange-rate", {
        credentials: "include",
      });
      
      if (exchangeRateResponse.ok) {
        const exchangeRateData = await exchangeRateResponse.json();
        setExchangeRate(exchangeRateData);
      } else {
        toast({
          title: "Failed to load exchange rate",
          description: "Using stored rates",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error fetching wallet data:", error);
      toast({
        title: "Error",
        description: "Failed to load wallet data",
        variant: "destructive",
      });
    } finally {
      setIsWalletLoading(false);
      setIsTransactionsLoading(false);
      setIsExchangeRateLoading(false);
    }
  }, [toast]);

  const sendPayment = async (invoice: string, amount: number, description?: string): Promise<boolean> => {
    try {
      // Validate wallet has sufficient balance
      if (!wallet || wallet.balance < amount) {
        toast({
          title: "Insufficient Balance",
          description: "You don't have enough funds for this transaction",
          variant: "destructive",
        });
        return false;
      }

      // For MVP, we'll simulate a payment by creating a transaction
      const response = await apiRequest("POST", "/api/wallet/transactions", {
        userId: 1, // For demo we use the first user
        amount: -amount, // Negative for sending
        description: description || "Payment sent",
        type: "send",
        status: "completed",
        invoice,
        paymentHash: `hash_${Date.now()}`,
        metadata: null
      });

      if (response.ok) {
        // Refresh wallet data
        await fetchWalletData();
        
        // Invalidate transaction cache
        queryClient.invalidateQueries({ queryKey: ['/api/wallet/transactions'] });
        
        toast({
          title: "Payment Sent",
          description: `${amount.toLocaleString()} sats sent successfully`,
        });
        return true;
      } else {
        const error = await response.json();
        toast({
          title: "Payment Failed",
          description: error.message || "Please try again",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      console.error("Error sending payment:", error);
      toast({
        title: "Payment Failed",
        description: "Please check your connection and try again",
        variant: "destructive",
      });
      return false;
    }
  };

  const generateInvoice = async (amount?: number, description?: string): Promise<string | null> => {
    try {
      // For MVP we'll return a mock invoice
      // In a real implementation, this would call the Lightning Network provider API
      const mockInvoice = `lnbc${amount || 10}n1p0zkhy3pp5l35l${Math.random().toString(36).substring(2, 10)}`;
      
      toast({
        title: "Invoice Generated",
        description: "Ready to receive payment",
      });
      
      return mockInvoice;
    } catch (error) {
      console.error("Error generating invoice:", error);
      toast({
        title: "Invoice Generation Failed",
        description: "Please try again later",
        variant: "destructive",
      });
      return null;
    }
  };

  return (
    <WalletContext.Provider
      value={{
        wallet,
        isWalletLoading,
        transactions,
        isTransactionsLoading,
        exchangeRate,
        isExchangeRateLoading,
        fetchWalletData,
        sendPayment,
        generateInvoice,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWalletContext() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error("useWalletContext must be used within a WalletProvider");
  }
  return context;
}
