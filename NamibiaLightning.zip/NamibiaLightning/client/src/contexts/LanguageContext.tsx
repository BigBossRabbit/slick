import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useTranslation } from "react-i18next";
import { apiRequest } from "@/lib/queryClient";
import { User } from "@shared/schema";

interface LanguageContextType {
  language: string;
  setLanguage: (lang: string) => Promise<void>;
  currency: string;
  setCurrency: (currency: string) => Promise<void>;
  dataSavingMode: boolean;
  setDataSavingMode: (mode: boolean) => Promise<void>;
  darkMode: boolean;
  setDarkMode: (mode: boolean) => Promise<void>;
  user: Omit<User, "password"> | null;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const { i18n } = useTranslation();
  const [user, setUser] = useState<Omit<User, "password"> | null>(null);
  const [language, setLanguageState] = useState("en");
  const [currency, setCurrencyState] = useState("NAD");
  const [dataSavingMode, setDataSavingModeState] = useState(false);
  const [darkMode, setDarkModeState] = useState(true); // Default to dark mode

  // Fetch user settings on mount
  useEffect(() => {
    async function fetchUserSettings() {
      try {
        const response = await fetch("/api/users/me", {
          credentials: "include",
        });
        
        if (response.ok) {
          const userData = await response.json();
          setUser(userData);
          setLanguageState(userData.language || "en");
          setCurrencyState(userData.currency || "NAD");
          setDataSavingModeState(userData.dataSavingMode || false);
          
          // Set i18n language
          if (userData.language) {
            await i18n.changeLanguage(userData.language);
          }
        }
      } catch (error) {
        console.error("Error fetching user settings:", error);
      }
    }
    
    fetchUserSettings();
  }, [i18n]);

  const setLanguage = async (lang: string) => {
    try {
      await i18n.changeLanguage(lang);
      setLanguageState(lang);
      
      // Update user settings
      await apiRequest("PUT", "/api/users/me/settings", {
        language: lang,
      });
    } catch (error) {
      console.error("Error setting language:", error);
    }
  };

  const setCurrency = async (newCurrency: string) => {
    try {
      setCurrencyState(newCurrency);
      
      // Update user settings
      await apiRequest("PUT", "/api/users/me/settings", {
        currency: newCurrency,
      });
    } catch (error) {
      console.error("Error setting currency:", error);
    }
  };

  const setDataSavingMode = async (mode: boolean) => {
    try {
      setDataSavingModeState(mode);
      
      // Update user settings
      await apiRequest("PUT", "/api/users/me/settings", {
        dataSavingMode: mode,
      });
    } catch (error) {
      console.error("Error setting data saving mode:", error);
    }
  };

  const setDarkMode = async (mode: boolean) => {
    try {
      setDarkModeState(mode);
      
      // Apply dark mode class to document
      if (mode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      
      // Update user settings
      await apiRequest("PUT", "/api/users/me/settings", {
        darkMode: mode,
      });
    } catch (error) {
      console.error("Error setting dark mode:", error);
    }
  };

  // Apply dark mode on initial load
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        currency,
        setCurrency,
        dataSavingMode,
        setDataSavingMode,
        darkMode,
        setDarkMode,
        user,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguageContext() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguageContext must be used within a LanguageProvider");
  }
  return context;
}
