import { createContext, ReactNode, useContext, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type Mint } from "@shared/schema";

interface ECashContextType {
  mints: Mint[];
  isMintsLoading: boolean;
  activeMint: Mint | null;
  setActiveMint: (mint: Mint | null) => void;
  addMint: (mint: Partial<Mint>) => Promise<Mint>;
  updateMint: (id: number, data: Partial<Mint>) => Promise<Mint | undefined>;
  deleteMint: (id: number) => Promise<void>;
}

const ECashContext = createContext<ECashContextType | undefined>(undefined);

export function ECashProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const [activeMint, setActiveMint] = useState<Mint | null>(null);
  
  // Fetch all mints
  const { data: mints = [], isLoading: isMintsLoading } = useQuery<Mint[]>({
    queryKey: ['/api/mints'],
    staleTime: 60 * 1000, // 1 minute
  });
  
  // Add a new mint
  const addMintMutation = useMutation({
    mutationFn: async (mintData: Partial<Mint>) => {
      const response = await apiRequest('POST', '/api/mints', mintData);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mints'] });
    },
  });
  
  // Update a mint
  const updateMintMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Mint> }) => {
      const response = await apiRequest('PUT', `/api/mints/${id}`, data);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mints'] });
    },
  });
  
  // Delete a mint
  const deleteMintMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/mints/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mints'] });
    },
  });
  
  // Add a new mint
  const addMint = async (mintData: Partial<Mint>): Promise<Mint> => {
    const result = await addMintMutation.mutateAsync(mintData);
    return result as Mint;
  };
  
  // Update a mint
  const updateMint = async (id: number, data: Partial<Mint>): Promise<Mint | undefined> => {
    const result = await updateMintMutation.mutateAsync({ id, data });
    return result as Mint;
  };
  
  // Delete a mint
  const deleteMint = async (id: number): Promise<void> => {
    await deleteMintMutation.mutateAsync(id);
  };
  
  return (
    <ECashContext.Provider
      value={{
        mints,
        isMintsLoading,
        activeMint,
        setActiveMint,
        addMint,
        updateMint,
        deleteMint,
      }}
    >
      {children}
    </ECashContext.Provider>
  );
}

export function useECashContext() {
  const context = useContext(ECashContext);
  if (context === undefined) {
    throw new Error("useECashContext must be used within an ECashProvider");
  }
  return context;
}