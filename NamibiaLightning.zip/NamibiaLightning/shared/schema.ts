import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  language: text("language").notNull().default("en"),
  currency: text("currency").notNull().default("NAD"),
  dataSavingMode: boolean("data_saving_mode").notNull().default(false),
  darkMode: boolean("dark_mode").notNull().default(true),
});

export const wallets = pgTable("wallets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  balance: integer("balance").notNull().default(0), // In satoshis
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
  walletType: text("wallet_type").notNull().default("lightning"), // "lightning", "liquid", "ecash"
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: integer("amount").notNull(), // Positive for receive, negative for send
  description: text("description"),
  type: text("type").notNull(), // "send", "receive", "offline"
  status: text("status").notNull(), // "pending", "completed", "failed"
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  invoice: text("invoice"),
  paymentHash: text("payment_hash"),
  walletType: text("wallet_type").notNull().default("lightning"), // "lightning", "liquid", "ecash"
  metadata: jsonb("metadata"), // For additional details like Machankura or eCash mint info
});

export const merchants = pgTable("merchants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  location: text("location").notNull(),
  coordinates: text("coordinates"),
  description: text("description"),
  acceptsLightning: boolean("accepts_lightning").notNull().default(true),
  rating: integer("rating"),
  featured: boolean("featured").notNull().default(false),
  iconType: text("icon_type"), // Font Awesome icon name
});

export const educationalContent = pgTable("educational_content", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull(),
  iconType: text("icon_type"), // Font Awesome icon name
  backgroundColor: text("background_color"),
});

// eCash mints
export const mints = pgTable("mints", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  url: text("url").notNull().unique(),
  active: boolean("active").notNull().default(true),
  balance: integer("balance").notNull().default(0), // In satoshis
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
  userId: integer("user_id").notNull().references(() => users.id),
  customKeyName: text("custom_key_name"), // User-defined name for this mint
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  language: true,
  currency: true,
  dataSavingMode: true,
  darkMode: true,
});

export const insertWalletSchema = createInsertSchema(wallets).pick({
  userId: true,
  balance: true,
  walletType: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  userId: true,
  amount: true,
  description: true,
  type: true,
  status: true,
  invoice: true,
  paymentHash: true,
  walletType: true,
  metadata: true,
});

export const insertMintSchema = createInsertSchema(mints).pick({
  name: true,
  url: true,
  active: true,
  balance: true,
  userId: true,
  customKeyName: true,
});

export const insertMerchantSchema = createInsertSchema(merchants).pick({
  name: true,
  category: true,
  location: true,
  coordinates: true,
  description: true,
  acceptsLightning: true,
  rating: true,
  featured: true,
  iconType: true,
});

export const insertEducationalContentSchema = createInsertSchema(educationalContent).pick({
  title: true,
  summary: true,
  content: true,
  category: true,
  iconType: true,
  backgroundColor: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertWallet = z.infer<typeof insertWalletSchema>;
export type Wallet = typeof wallets.$inferSelect;

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

export type InsertMerchant = z.infer<typeof insertMerchantSchema>;
export type Merchant = typeof merchants.$inferSelect;

export type InsertEducationalContent = z.infer<typeof insertEducationalContentSchema>;
export type EducationalContent = typeof educationalContent.$inferSelect;

export type InsertMint = z.infer<typeof insertMintSchema>;
export type Mint = typeof mints.$inferSelect;
