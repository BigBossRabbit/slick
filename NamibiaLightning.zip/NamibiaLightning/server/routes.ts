import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertTransactionSchema } from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      await storage.createWallet({ userId: user.id, balance: 0 });
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid user data", errors: error.format() });
      } else {
        res.status(500).json({ message: "Failed to create user" });
      }
    }
  });

  app.get("/api/users/me", async (req: Request, res: Response) => {
    // For demo purposes, return the first user
    const users = Array.from((await storage.getMerchants()).values());
    if (users.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }
    
    const user = await storage.getUser(1);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Remove password from response
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  app.put("/api/users/me/settings", async (req: Request, res: Response) => {
    try {
      const settingsSchema = z.object({
        language: z.enum(["en", "af", "ow"]).optional(),
        currency: z.string().optional(),
        dataSavingMode: z.boolean().optional()
      });
      
      const settings = settingsSchema.parse(req.body);
      
      // For demo purposes, update the first user
      const user = await storage.getUser(1);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(user.id, settings);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid settings data", errors: error.format() });
      } else {
        res.status(500).json({ message: "Failed to update settings" });
      }
    }
  });

  // Wallet routes
  app.get("/api/wallet", async (req: Request, res: Response) => {
    try {
      // For demo purposes, get the wallet for the first user
      const wallet = await storage.getWallet(1);
      
      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" });
      }
      
      res.json(wallet);
    } catch (error) {
      res.status(500).json({ message: "Failed to get wallet" });
    }
  });

  app.post("/api/wallet/transactions", async (req: Request, res: Response) => {
    try {
      const transactionData = insertTransactionSchema.parse(req.body);
      
      // For demo purposes, use the first user
      const wallet = await storage.getWallet(1);
      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" });
      }
      
      // Update wallet balance
      const newBalance = wallet.balance + transactionData.amount;
      await storage.updateWalletBalance(1, newBalance);
      
      // Create transaction
      const transaction = await storage.createTransaction(transactionData);
      
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid transaction data", errors: error.format() });
      } else {
        res.status(500).json({ message: "Failed to create transaction" });
      }
    }
  });

  app.get("/api/wallet/transactions", async (req: Request, res: Response) => {
    try {
      // For demo purposes, get transactions for the first user
      const transactions = await storage.getTransactions(1);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get transactions" });
    }
  });

  // Merchant routes
  app.get("/api/merchants", async (req: Request, res: Response) => {
    try {
      const { category } = req.query;
      
      let merchants;
      if (category && typeof category === 'string') {
        merchants = await storage.getMerchantsByCategory(category);
      } else {
        merchants = await storage.getMerchants();
      }
      
      res.json(merchants);
    } catch (error) {
      res.status(500).json({ message: "Failed to get merchants" });
    }
  });

  app.get("/api/merchants/featured", async (req: Request, res: Response) => {
    try {
      const merchants = await storage.getFeaturedMerchants();
      res.json(merchants);
    } catch (error) {
      res.status(500).json({ message: "Failed to get featured merchants" });
    }
  });

  app.get("/api/merchants/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid merchant ID" });
      }
      
      const merchant = await storage.getMerchant(id);
      
      if (!merchant) {
        return res.status(404).json({ message: "Merchant not found" });
      }
      
      res.json(merchant);
    } catch (error) {
      res.status(500).json({ message: "Failed to get merchant" });
    }
  });

  // Educational content routes
  app.get("/api/educational-content", async (req: Request, res: Response) => {
    try {
      const content = await storage.getEducationalContents();
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to get educational content" });
    }
  });

  app.get("/api/educational-content/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid content ID" });
      }
      
      const content = await storage.getEducationalContent(id);
      
      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }
      
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to get educational content" });
    }
  });

  // Exchange rate API (simplified for demo)
  app.get("/api/exchange-rate", (req: Request, res: Response) => {
    // Fixed conversion rate for demo: 1 BTC = 1,000,000,000 sats = 860,000 NAD
    const satoshiToNAD = 0.00086; // 1 sat = 0.00086 NAD
    res.json({ 
      satoshiToNAD,
      lastUpdated: new Date().toISOString()
    });
  });
  
  // eCash mint routes
  app.get("/api/mints", async (req: Request, res: Response) => {
    try {
      const userId = 1; // Hardcoded for demo, replace with actual auth
      const mints = await storage.getMints(userId);
      res.json(mints);
    } catch (error) {
      res.status(500).json({ message: "Failed to get mints" });
    }
  });
  
  app.get("/api/mints/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid mint ID" });
      }
      
      const mint = await storage.getMint(id);
      
      if (!mint) {
        return res.status(404).json({ message: "Mint not found" });
      }
      
      res.json(mint);
    } catch (error) {
      res.status(500).json({ message: "Failed to get mint" });
    }
  });
  
  app.post("/api/mints", async (req: Request, res: Response) => {
    try {
      const userId = 1; // Hardcoded for demo, replace with actual auth
      const mint = {
        ...req.body,
        userId
      };
      const newMint = await storage.createMint(mint);
      res.status(201).json(newMint);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid mint data", errors: error.format() });
      } else {
        res.status(500).json({ message: "Failed to create mint" });
      }
    }
  });
  
  app.put("/api/mints/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid mint ID" });
      }
      
      const existingMint = await storage.getMint(id);
      if (!existingMint) {
        return res.status(404).json({ message: "Mint not found" });
      }
      
      const updatedMint = await storage.updateMint(id, req.body);
      res.json(updatedMint);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid mint data", errors: error.format() });
      } else {
        res.status(500).json({ message: "Failed to update mint" });
      }
    }
  });
  
  app.delete("/api/mints/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid mint ID" });
      }
      
      const existingMint = await storage.getMint(id);
      if (!existingMint) {
        return res.status(404).json({ message: "Mint not found" });
      }
      
      await storage.deleteMint(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete mint" });
    }
  });

  // Create the HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
