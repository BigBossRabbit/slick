import { 
  users, type User, type InsertUser,
  wallets, type Wallet, type InsertWallet,
  transactions, type Transaction, type InsertTransaction,
  merchants, type Merchant, type InsertMerchant,
  educationalContent, type EducationalContent, type InsertEducationalContent,
  mints, type Mint, type InsertMint
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined>;
  
  // Wallet operations
  getWallet(userId: number): Promise<Wallet | undefined>;
  createWallet(wallet: InsertWallet): Promise<Wallet>;
  updateWalletBalance(userId: number, newBalance: number): Promise<Wallet | undefined>;
  
  // Transaction operations
  getTransactions(userId: number): Promise<Transaction[]>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Merchant operations
  getMerchants(): Promise<Merchant[]>;
  getMerchantsByCategory(category: string): Promise<Merchant[]>;
  getFeaturedMerchants(): Promise<Merchant[]>;
  getMerchant(id: number): Promise<Merchant | undefined>;
  createMerchant(merchant: InsertMerchant): Promise<Merchant>;
  
  // Educational content operations
  getEducationalContents(): Promise<EducationalContent[]>;
  getEducationalContent(id: number): Promise<EducationalContent | undefined>;
  createEducationalContent(content: InsertEducationalContent): Promise<EducationalContent>;
  
  // eCash mint operations
  getMints(userId: number): Promise<Mint[]>;
  getMint(id: number): Promise<Mint | undefined>;
  createMint(mint: InsertMint): Promise<Mint>;
  updateMint(id: number, data: Partial<InsertMint>): Promise<Mint | undefined>;
  deleteMint(id: number): Promise<boolean>;
}

import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }

  // Wallet operations
  async getWallet(userId: number): Promise<Wallet | undefined> {
    const [wallet] = await db.select().from(wallets).where(eq(wallets.userId, userId));
    return wallet || undefined;
  }

  async createWallet(insertWallet: InsertWallet): Promise<Wallet> {
    const walletWithDate = {
      ...insertWallet,
      lastUpdated: new Date()
    };
    
    const [wallet] = await db
      .insert(wallets)
      .values(walletWithDate)
      .returning();
    return wallet;
  }

  async updateWalletBalance(userId: number, newBalance: number): Promise<Wallet | undefined> {
    const [updatedWallet] = await db
      .update(wallets)
      .set({ 
        balance: newBalance,
        lastUpdated: new Date()
      })
      .where(eq(wallets.userId, userId))
      .returning();
    return updatedWallet || undefined;
  }

  // Transaction operations
  async getTransactions(userId: number): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.timestamp));
  }

  async getTransaction(id: number): Promise<Transaction | undefined> {
    const [transaction] = await db
      .select()
      .from(transactions)
      .where(eq(transactions.id, id));
    return transaction || undefined;
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const transactionWithTimestamp = {
      ...insertTransaction,
      timestamp: new Date()
    };
    
    const [transaction] = await db
      .insert(transactions)
      .values(transactionWithTimestamp)
      .returning();

    // Update wallet balance if transaction has a valid userId and amount
    if (transaction.userId && transaction.amount) {
      const wallet = await this.getWallet(transaction.userId);
      if (wallet) {
        const newBalance = wallet.balance + transaction.amount;
        await this.updateWalletBalance(transaction.userId, newBalance);
      }
    }

    return transaction;
  }

  // Merchant operations
  async getMerchants(): Promise<Merchant[]> {
    return await db.select().from(merchants);
  }

  async getMerchantsByCategory(category: string): Promise<Merchant[]> {
    return await db
      .select()
      .from(merchants)
      .where(eq(merchants.category, category));
  }

  async getFeaturedMerchants(): Promise<Merchant[]> {
    return await db
      .select()
      .from(merchants)
      .where(eq(merchants.featured, true));
  }

  async getMerchant(id: number): Promise<Merchant | undefined> {
    const [merchant] = await db
      .select()
      .from(merchants)
      .where(eq(merchants.id, id));
    return merchant || undefined;
  }

  async createMerchant(insertMerchant: InsertMerchant): Promise<Merchant> {
    const [merchant] = await db
      .insert(merchants)
      .values(insertMerchant)
      .returning();
    return merchant;
  }

  // Educational content operations
  async getEducationalContents(): Promise<EducationalContent[]> {
    return await db.select().from(educationalContent);
  }

  async getEducationalContent(id: number): Promise<EducationalContent | undefined> {
    const [content] = await db
      .select()
      .from(educationalContent)
      .where(eq(educationalContent.id, id));
    return content || undefined;
  }

  async createEducationalContent(insertContent: InsertEducationalContent): Promise<EducationalContent> {
    const [content] = await db
      .insert(educationalContent)
      .values(insertContent)
      .returning();
    return content;
  }
  
  // eCash mint operations
  async getMints(userId: number): Promise<Mint[]> {
    return await db
      .select()
      .from(mints)
      .where(eq(mints.userId, userId));
  }

  async getMint(id: number): Promise<Mint | undefined> {
    const [mint] = await db
      .select()
      .from(mints)
      .where(eq(mints.id, id));
    return mint || undefined;
  }

  async createMint(insertMint: InsertMint): Promise<Mint> {
    const [mint] = await db
      .insert(mints)
      .values(insertMint)
      .returning();
    return mint;
  }

  async updateMint(id: number, data: Partial<InsertMint>): Promise<Mint | undefined> {
    const [updatedMint] = await db
      .update(mints)
      .set(data)
      .where(eq(mints.id, id))
      .returning();
    return updatedMint || undefined;
  }

  async deleteMint(id: number): Promise<boolean> {
    const result = await db
      .delete(mints)
      .where(eq(mints.id, id));
    return true;
  }

  // Initialize sample data
  async initializeSampleData() {
    // Check if there's already data
    const existingUsers = await db.select().from(users);
    if (existingUsers.length > 0) {
      return; // Database already has data
    }

    // Sample user
    const user = await this.createUser({
      username: "demo_user",
      password: "password123",
      language: "en",
      currency: "NAD",
      dataSavingMode: false
    });

    // Sample wallet
    await this.createWallet({
      userId: user.id,
      balance: 217542 // 217,542 sats
    });

    // Sample transactions
    await this.createTransaction({
      userId: user.id,
      amount: -5000,
      description: "Sent Payment",
      type: "send",
      status: "completed",
      invoice: "lnbc10n1p0zkhy3pp5l35l...",
      paymentHash: "abc123hash",
      metadata: null
    });

    await this.createTransaction({
      userId: user.id,
      amount: 12500,
      description: "Received Payment",
      type: "receive",
      status: "completed",
      invoice: "lnbc10n1p0zkhy3pp5l35l...",
      paymentHash: "def456hash",
      metadata: null
    });

    await this.createTransaction({
      userId: user.id,
      amount: -8000,
      description: "Offline Payment via Machankura",
      type: "offline",
      status: "completed",
      invoice: null,
      paymentHash: "ghi789hash",
      metadata: { machankuraType: "sms" }
    });

    // Sample merchants
    await this.createMerchant({
      name: "Windhoek Coffee Shop",
      category: "Restaurants",
      location: "Windhoek, Namibia",
      coordinates: "-22.5609,17.0658",
      description: "A cozy coffee shop serving locally roasted coffee.",
      acceptsLightning: true,
      rating: 48, // 4.8 stars
      featured: true,
      iconType: "utensils"
    });

    await this.createMerchant({
      name: "Swakopmund Tech",
      category: "Technology",
      location: "Swakopmund, Namibia",
      coordinates: "-22.6784,14.5258",
      description: "Electronics and tech gadgets with Bitcoin payments.",
      acceptsLightning: true,
      rating: 45, // 4.5 stars
      featured: true,
      iconType: "laptop"
    });

    await this.createMerchant({
      name: "Namibian Grill House",
      category: "Restaurants",
      location: "Windhoek, Namibia",
      coordinates: "-22.5700,17.0785",
      description: "Traditional Namibian cuisine with an outdoor seating area.",
      acceptsLightning: true,
      rating: 48, // 4.8 stars
      featured: false,
      iconType: "utensils"
    });

    await this.createMerchant({
      name: "Namibian Crafts",
      category: "Retail",
      location: "Swakopmund, Namibia",
      coordinates: "-22.6790,14.5240",
      description: "Handmade Namibian crafts and souvenirs.",
      acceptsLightning: true,
      rating: 45, // 4.5 stars
      featured: false,
      iconType: "tshirt"
    });

    await this.createMerchant({
      name: "Desert View Lodge",
      category: "Tourism",
      location: "Walvis Bay, Namibia",
      coordinates: "-22.9457,14.5050",
      description: "Accommodation with stunning views of the Namib Desert.",
      acceptsLightning: true,
      rating: 49, // 4.9 stars
      featured: false,
      iconType: "hotel"
    });

    // Sample educational content
    await this.createEducationalContent({
      title: "Bitcoin Basics for Namibians",
      summary: "Learn how Bitcoin works and why it matters in Namibia",
      content: "Bitcoin is a decentralized digital currency that operates without a central authority...",
      category: "basics",
      iconType: "graduation-cap",
      backgroundColor: "primary/10"
    });

    await this.createEducationalContent({
      title: "Securing Your Bitcoin",
      summary: "Best practices for keeping your sats safe",
      content: "Keeping your bitcoin secure is crucial. Here are some best practices to follow...",
      category: "security",
      iconType: "shield-alt",
      backgroundColor: "accent/10"
    });
  }
}

export const storage = new DatabaseStorage();
